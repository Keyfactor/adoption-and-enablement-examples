#!/bin/bash

if [[ $(id -u) -ne 0 ]]; then
    echo 'Elevation is required to run this script'
    exit 1
fi

OPTIONS=fv
LONGOPTS=help,service-name:,force,verbose
PARSED=$(getopt --options=$OPTIONS --longoptions=$LONGOPTS --name "$0" -- "$@")

eval set -- "$PARSED"

scriptDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Set default parameters
force=false
verbose=false

# Display helpful information
display_help() 
{
    echo "[Optional] --service-name - Name of the systemd service to remove. If not supplied, keyfactor-orchestrator-default.service will be used."
    echo "[Optional] -f, --force - If specified, you will not be prompted for confirmation before any changes are applied"
    echo "[Optional] -v, --verbose"

    exit 0 ;
}

# Remove an existing Keyfactor Orchestrator service
remove_orchestrator_service()
{
    serviceToRemove=$1

    if [[ -z $serviceToRemove ]]; then
        return
    fi

    echo "Removing existing service ${serviceToRemove%.*}"
    systemctl stop "$serviceToRemove"
    systemctl disable "$serviceToRemove"

    rm "/etc/systemd/system/$serviceToRemove" &> /dev/null
}

# extract options and their arguments into variables.
while true ; do
    case "$1" in
        --service-name)
            serviceName="$2" ;
            shift 2 ;;

        -f|--force)
            force=true ; shift ;;

        -v|--verbose)
            verbose=true ; shift ;;
        --) shift ; break ;;
        *) echo "Unexpected argument $1. Run with --help for assistance." ; exit 1 ;;
    esac
done

# Validate parameters and set defaults
if [ -z "$serviceName" ]; then 
    serviceName="keyfactor-orchestrator-default.service"
fi

# prompt user for confirmation 
if ! $force; then 
    echo "This script will uninstall the Keyfactor Orchestrator. Are you sure you want to proceed: "
    read confirmation

    match="$(echo $confirmation | grep -E '[yY]|[(YES)(yes)(Yes)]')"
    if [ -z "$match" ]; then 
        exit 0;
    fi
fi

pushd "$scriptDir" > /dev/null

# remove the orchestrator service
if $verbose; then 
    echo "Removing orchestrator service..."
fi

remove_orchestrator_service "$serviceName"

# remove the files
if $verbose; then 
    echo "Removing '$scriptDir'..."
fi

rm -r "$scriptDir"

echo "Keyfactor Orchestrator successfully uninstalled"

popd > /dev/null
