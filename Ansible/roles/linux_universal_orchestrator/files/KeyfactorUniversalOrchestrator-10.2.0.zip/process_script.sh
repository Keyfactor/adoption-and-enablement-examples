scriptContext="$1";
scriptLocation="$2";

# grab the script context and publish it for the child script
export keyfactorOrchestratorBashDriverContext="$scriptContext";

# run the script
. "$scriptLocation";

# send the results back to the orchestrator
echo "$keyfactorOrchestratorBashDriverContext";
