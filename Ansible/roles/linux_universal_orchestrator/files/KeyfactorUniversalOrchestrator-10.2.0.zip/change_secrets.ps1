﻿#Requires -RunAsAdministrator

<#
.SYNOPSIS
Reconfigures the Orchestrator's Secret Values

.PARAMETER WebCredential
PSCredential object containing the username and password that the orchestrator will use to connect to Keyfactor.

.PARAMETER ClientAuthPassword
Password used when leveraging certificate-based authentication to Keyfactor.

.PARAMETER SecretsPath
Absolute path to the orchestratorsecrets configuration file.

.DESCRIPTION
Specify a path to the secrets file as well as a username and password or a client auth password to authenticate the orchestrator to Keyfactor.
Defaults to using a username and password.

#>

[CmdletBinding(PositionalBinding=$false, DefaultParameterSetName='UsingCredentials')]
Param(
    [Parameter(
        Mandatory=$true, 
        HelpMessage='PSCredential object containing the username and password that the orchestrator will use to connect to Keyfactor.', 
        ParameterSetName='UsingCredentials'
    )]
    [PSCredential]$WebCredential,

    [Parameter(
        Mandatory=$true, 
        HelpMessage='Password used when leveraging certificate-based authentication to Keyfactor.', 
        ParameterSetName='UsingClientAuth'
    )]
    [string]$ClientAuthPassword,

    [Parameter(
        Mandatory=$true, 
        HelpMessage='Absolute path to the orchestratorsecrets configuration file.'
    )]
	[ValidateScript({
		$_ = $_.Replace('"', '')
		if (-not [System.IO.Path]::IsPathRooted($_))
		{
			Throw [System.ArgumentException] "Please specify an absolute path to the secrets file."
		}
		else
		{
			$True
		}
	})]
    [string]$SecretsPath
)

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'
$WarningPreference = 'Continue'

# Relative paths
$RelativeOrchestratorExePath = '..\Orchestrator.exe'

$SecretsFileName = 'orchestratorsecrets.json'

function Add-PermissionToFile {
[CmdletBinding()]
Param([string]$Path, [string]$User, [System.Security.AccessControl.FileSystemRights]$Rights)

    $acl = Get-Acl -Path $Path
    Write-Verbose "Granting rights $Rights to $User on $Path"

    if(Test-Path -Path $Path -PathType Container) {
        $acl.AddAccessRule((New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList ($User, $Rights, 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
    }
    else {
        $acl.AddAccessRule((New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList ($User, $Rights, 'Allow')))
    }

    Set-Acl -Path $Path -AclObject $acl
}

function Set-KeyfactorOrchestratorSecrets {
[CmdletBinding()]
Param()

    $secretCredentials = @{}
    if ($WebCredential)
    {
        $secretCredentials['Username'] = $WebCredential.UserName
        $secretCredentials['Password'] = $WebCredential.GetNetworkCredential().Password
    }

    if ($ClientAuthPassword)
    {
        $secretCredentials['ClientAuthCertificatePassword'] = $ClientAuthPassword
    }

    Write-Verbose "Saving secrets to '$SecretsPath'"
    $secretsFileContent = @{'Secrets' = $secretCredentials}
    ConvertTo-Json $secretsFileContent | Set-Content $SecretsPath

    Write-Verbose "Restricting ACL for $secretsPath"
    $secretsAcl = Get-Acl -Path $SecretsPath
    $secretsAcl.SetSecurityDescriptorSddlForm('D:PAI(A;;FA;;;BA)', 'Access') # Restrict to only built-in admins
    Set-Acl -Path $SecretsPath -AclObject $secretsAcl

    Write-Information "Saved secrets to '$SecretsPath'"
}

function Restart-KeyfactorOrchestratorService {
[CmdletBinding()]
Param([Parameter(Mandatory=$true)][string]$ServicePath)

    Write-Verbose "Checking for existing service at path '$ServicePath'"
    $cimServices = @(Get-CimInstance Win32_Service -Verbose:$false -Filter "PathName LIKE '%$(Split-Path -Leaf $ServicePath)%'" | where -FilterScript {$_.PathName.Trim('"') -eq $ServicePath})

	if ($cimServices) 
	{
        ForEach ($service in $cimServices)
        {
            $serviceName = $service.Name
            $serviceUser = $service.StartName

            Write-Verbose "Granting necessary file permissions to $($serviceUser)" # Give access to service account
            Add-PermissionToFile -Path $SecretsPath -User $serviceUser -Rights Modify

			Write-Information "Restarting service $serviceName"
			Restart-Service $serviceName
        }
	}
    else
    {
        Write-Warning "An existing orchestrator service could not be found. Please start the orchestrator to encrypt the secrets file."
    }
}

# MAIN

# Remove double quotes (useful for when prompted for this parameter instead of specifying it directly)
$SecretsPath = $SecretsPath.Replace('"', '')

# Validate the existence of the specified path
if(-not (Test-Path -Path $SecretsPath)) {
	Write-Error "There was an error finding the secrets file at '$SecretsPath'. The specified file does not exist."
}

# Validate that the name of the file specified is correct
if (-not ((Split-Path $SecretsPath -leaf) -eq $SecretsFileName))
{
	Write-Error "There was an error finding the secrets file at '$SecretsPath'. The specified file name is invalid."
}

# Validate the existence of the Keyfactor Orchestrator
$configurationDirectory = Split-Path -Path $SecretsPath
$resolvedServicePath = Join-Path $configurationDirectory $RelativeOrchestratorExePath -Resolve -ErrorAction SilentlyContinue
if ((-not $resolvedServicePath) -or (-not (Get-Item $resolvedServicePath)))
{
	Write-Error "The secrets path specified is not contained in an installation of the Keyfactor Orchestrator."
}

Set-KeyfactorOrchestratorSecrets
Restart-KeyfactorOrchestratorService -ServicePath $resolvedServicePath
# SIG # Begin signature block
# MIIpQAYJKoZIhvcNAQcCoIIpMTCCKS0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBK+ViVC2cFBRZJ
# jaOwP4aOqxb8YEf/4p+bHp2sl18u5KCCDi4wggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggd2MIIFXqADAgECAhAPhranjL3m2+B++PUunMN2MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjMwMTMxMDAwMDAwWhcNMjQwMTMw
# MjM1OTU5WjB7MQswCQYDVQQGEwJVUzENMAsGA1UECBMET2hpbzEVMBMGA1UEBxMM
# SW5kZXBlbmRlbmNlMRcwFQYDVQQKEw5LZXlmYWN0b3IsIEluYzEUMBIGA1UECxML
# RW5naW5lZXJpbmcxFzAVBgNVBAMTDktleWZhY3RvciwgSW5jMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEA6eKOGZEUVtAocGpTHAy1/Bgxl1tOWPqdFzFG
# 0w8K+3gGUOB985b+uGJTB6bxYdwtUJcsmZ3cSwSKYbWJBPswivciR9exow7R4asM
# Fz2tSuLkHNEdOg6A5h3Cgl26t3LdEKS/SWNWnhS9GI1r+Cb2B/9/ptJ3fsaR8Z94
# qOz1YfjSK0kxRRABzi6GsP9OXikmFe4ubbnd347B7dTShJFtKhQPhIMOn+ac3YcI
# Jac3+5m7KiLSD6M+hdPS0v1jhBiyn0sS4zrVLrL7IAkNj3mhFCtg2U5Z+Xr4kH+z
# pbfp2v71lyErlVWb5WwdJjGEOo/LSfHZZbwIReZtt2p7R5DCUmFd7ScYimW5+lhK
# 8NGrdvsR4xIWRSBhRBus6t3fnWDhvvDebSKAzC2E39xwqjtiA5hmIF5lrDujOoTK
# dOnnApR55/moQ1GYQX5mAK0rKs90u+PGMEvAG8+E88wm+kXZJswlfJr3Y0nJ7kiA
# t1szJOMU5D8EM1DnSsFqCPWnwgGSgjSOzKebFrYHf7Fs33XmTSwOkusi4iq0bx7G
# WKoKVVZKl1KqN3Wunratgna+GLgdLJA86aBx0HFD8YLM3JlhjnAlxEGtKRiYXpq7
# VyfL7RyR8jcjqnmnynzCEdnNvKZNPQKkc21lQj1okw8ulxMiwceK1I9soK0joWk9
# uvJIVy0CAwEAAaOCAgYwggICMB8GA1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl
# 9E5CMB0GA1UdDgQWBBRFBxQUF8Mbu1SWiMft7H5L5JJc/zAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCBqjBToFGgT4ZNaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25p
# bmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0dHA6Ly9jcmw0LmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNI
# QTM4NDIwMjFDQTEuY3JsMD4GA1UdIAQ3MDUwMwYGZ4EMAQQBMCkwJwYIKwYBBQUH
# AgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzCBlAYIKwYBBQUHAQEEgYcw
# gYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEF
# BQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAU66XgPDhk2SpLMNQtdTMn//V5Xq3Sh7E
# xctsMkQ7BjHBg7ngpmQ8iNSGCfgmQgEp3r4FGKxVegtAwOiOOLzz3VSwCl4mN+Dv
# NauYHHmR2/YGlJKVKnYqVf7WS00dBNOYrh2p5sz+ZjI1vVaBJf8/MHN7r3eKDjyr
# PlH2S3VAivFyUMYbSrCsxJcRBDdCgq2EeKJkYz2mCIV6F0LGqzuse/5CXWCbG4BP
# cMGNX+sd6CZ0SZ7RLfPLSz/d5u6L5G2w4uHPp2gSNXUw90C8q+nxCHDCzJFmXwJu
# DhUchPgcb6Nm5bNawBVrV7VlHP0KoxSTWemB4Xs8axuJ+I1gwrhow1G/EKgD1J0A
# 5+plRlwvVTomIp8empYpNAJfmLKgvEPKHjVaFoeQ0qxlNEixp4YD4wZO0U8cYhH2
# 0wFcEAR+jcxyv5VWWGMj4JMcdC6YorUxG/29U8fG48GldCEz5gkJ4mhbOF11RfR5
# QffkblniZZ7+qZrzQOkMTfGWAI638uDXgCOaejQDoeCKRz6iNbXNpj/fcB7e1Omg
# vmfKK0Ca2kC8PLSiIP5JPmFmplS/5Y136w0JRld18pbgmbTPLzfgSKCGAH5RGa9K
# C5SGS+JUhMJ6MxTKc97dXfhZaE4KUjiKQj2iLPnXm1AZDkt4C9coxnKbwbFic0Bw
# uSelnVg6avcxghpoMIIaZAIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5E
# aWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2Rl
# IFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTECEA+GtqeMvebb4H749S6c
# w3YwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3AgEMMQIwADAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQg74xB4mX3Y6Ckswi1dgWtU9pcle/cVx1TqpKQ4lagfQow
# DQYJKoZIhvcNAQEBBQAEggIAT8FWPCkBH0AMqmrfwGR1UNKvLh9ORJGdHUu0mUys
# FMkUjnhd+NPFQL4rb+5JNMHLaqnJ4OUk9kW68QPLoHIWNh0skAo2d0q4f0Th0S/C
# MVDx2P8j0uYDjyeGaVgxRbclxR6pMVz/Vu2N3C1HwE/CkCVaF7CnYTMsm/G5PlYQ
# 7KF2ZXRR2ClGTON2M5A/0nAfT7q8s0+EahQ/yv9TUVtdzTcW3+NKKs3lbxQAW1qw
# R9ELkUlrDavFyIG9N7hTP1ba3GM4hjBxiOxveiKnND/zqosISnB5iKAlnGvODqjF
# mF70qsAzz8VfAW09ubPV6gmwQV0FDlGZYd/DWYMT4A0HI+IoHhl9zeFz/e6tCTSC
# W6L561/Z3KtgIBVeUagAQcqJoeyq4Qyvg4rrE2aQtUOx/+9K01fOdAGj+pGo02zT
# bka+qGHBnhvcVzEWXJinuLRxH1eG4MW2qhoDXTAMg6pIYpve5PCqiT7lYJo9XPbq
# FNc/vy5ZVgPYoMaLZ0yZGNHB2ct5sxmmq3lERt3iNNbS3h+thHSff6+AjPu7puNl
# XG3IHLaWHNvF481XwbqfFxgVqTsJB8l8NSE5045NE3BzriTdUseSJrzwNTOAM5TL
# 2SIFV5WBOcEHu0v9oy2MbFPOXO1yCDcQJnAvTIFNvQR2j6Qqwsi+ZIQ/UEG25NmL
# Igehghc+MIIXOgYKKwYBBAGCNwMDATGCFyowghcmBgkqhkiG9w0BBwKgghcXMIIX
# EwIBAzEPMA0GCWCGSAFlAwQCAQUAMHgGCyqGSIb3DQEJEAEEoGkEZzBlAgEBBglg
# hkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgmPFlAd8ml607ZnWtL4xGK+yJymTG
# M+ZUQ08CkI4NTmICEQCZaM/ZLnko/T8Hqg8UXw7MGA8yMDIzMDQwNzE1Mjk0MVqg
# ghMHMIIGwDCCBKigAwIBAgIQDE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsF
# ADBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNV
# BAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1w
# aW5nIENBMB4XDTIyMDkyMTAwMDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UE
# BhMCVVMxETAPBgNVBAoTCERpZ2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1l
# c3RhbXAgMjAyMiAtIDIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP
# 7KUmOsap8mu7jcENmtuh6BSFdDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9
# BoMW15GSOBwxApb7crGXOlWvM+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW
# 4VbGwLpkU7sqFudQSLuIaQyIxvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJh
# vKo6B332q27lZt3iXPUv7Y3UTZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4
# DeWMlF0ZWr/1e0BubxaompyVR4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AG
# N7oI2TWmtR7aeFgdOej4TJEQln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMR
# oku7mL/6T+R7Nu8GRORV/zbq5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5Af
# J7fSqxTlOGaHUQhr+1NDOdBk+lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU
# 4b3ZXUtuMZQpi+ZBpGWUwFjl5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5q
# BzliGcnWhX8T2Y15z2LF7OF7ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstk
# ifGxxLjnU15fVdJ9GSlZA076XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqU
# FN9SnDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl
# 5vdyipjDd9Rk/BX7NsJJUSx4iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18
# hc1Tna9i4mFmoxQqRYdKmEIrUPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ
# 6KO4ndetHxy47JhB8PYOgPvk/9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/
# fl4JrXZUinRtytIFZyt26/+YsiaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIM
# kU88ZpSvXQJT657inuTTH4YBZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMM
# xkZAO85dNdRZPkOaGK7DycvD+5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7
# /lxClIGUgp2sCovGSxVK05iQRWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0
# Ti7aHh2MWsgemtXC8MYiqE+bvdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpL
# EQLIgpzJGgV8unG1TnqZbPTontRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+
# 8JeEeOMIA11HLGOoJTiXAdI/Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYks
# Jxlh9ncBjDCCBq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYqXlswDQYJKoZIhvcN
# AQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3Rl
# ZCBSb290IEc0MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIzNTk1OVowYzELMAkG
# A1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdp
# Q2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJs8E9cklRVcclA8Ty
# kTepl1Gh1tKD0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJC3+dH54PMx9QEwsm
# c5Zt+FeoAn39Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+QtxnjupRPfDWVtTn
# KC3r07G1decfBmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3eZ9drMvohGS0UvJ2
# R/dhgxndX7RUCyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbFHc02DVzV5huowWR0
# QKfAcsW6Th+xtVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71h6aPTnYVVSZwmCZ/
# oBpHIEPjQ2OAe3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseSv6De4z6ic/rnH1ps
# lPJSlRErWHRAKKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj1QPgv/CiPMpC3BhI
# fxQ0z9JMq++bPf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2LINIsVzV5K6jzRWC8
# I41Y99xh3pP+OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJjAw7W4oiqMEmCPkU
# EBIDfV8ju2TjY+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAOhFTuzuldyF4wEr1G
# nrXTdrnSDmuZDNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEA
# MB0GA1UdDgQWBBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNVHSMEGDAWgBTs1+OC
# 0nFdZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwdwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5k
# aWdpY2VydC5jb20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSG
# Mmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQu
# Y3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0B
# AQsFAAOCAgEAfVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88wU86/GPvHUF3iSyn7
# cIoNqilp/GnBzx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZvxFBMYh0MCIKoFr2p
# Vs8Vc40BIiXOlWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+RZp4snuCKrOX9jLxk
# Jodskr2dfNBwCnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM8HKjI/rAJ4JErpkn
# G6skHibBt94q6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/Ex8HBanHZxhOACcS2
# n82HhyS7T6NJuXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd/yVjmScsPT9rp/Fm
# w0HNT7ZAmyEhQNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFPvT87eK1MrfvElXvt
# Cl8zOYdBeHo46Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHicsJttvFXseGYs2uJPU
# 5vIXmVnKcPA3v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2VQbc61RWYMbRiCQ8K
# vYHZE/6/pNHzV9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ8GV2QqYphwlHK+Z/
# GqSFD/yYlvZVVCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr9u3WfPwwggWNMIIE
# daADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNV
# BAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdp
# Y2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAe
# Fw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUw
# EwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20x
# ITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcN
# AQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC
# 4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWl
# fr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1j
# KS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dP
# pzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3
# pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJ
# pMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aa
# dMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXD
# j/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB
# 4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ
# 33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amy
# HeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC
# 0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823I
# DzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYD
# VR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcN
# AQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxpp
# VCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6
# mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPH
# h6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCN
# NWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg6
# 2fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQxggN2MIIDcgIBATB3MGMxCzAJBgNV
# BAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNl
# cnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAxN
# aXJLlPo8Kko9KQeAPVowDQYJYIZIAWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0G
# CyqGSIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yMzA0MDcxNTI5NDFaMCsGCyqG
# SIb3DQEJEAIMMRwwGjAYMBYEFPOHIk2GM4KSNamUvL2Plun+HHxzMC8GCSqGSIb3
# DQEJBDEiBCBas4K3r3wFe18PVTZgCGWKfMqgG49dVqee7/uwU/TIVDA3BgsqhkiG
# 9w0BCRACLzEoMCYwJDAiBCDH9OG+MiiJIKviJjq+GsT8T+Z4HC1k0EyAdVegI7W2
# +jANBgkqhkiG9w0BAQEFAASCAgCUsZyHIa/7xJqA0iziKGW3HrMkGpAoLPWuY1Nu
# uIFCR6jgq/IEvLdpK8UEcxMCRzS90XmKfOpGNitR30CinuHca6Xj4VBpVDOimvOI
# ljR+ycrC8VBsixbrVkXekIQy8HkHet/enrsEL6RSmgbJgMLshfCENHsfV3heJsy8
# cfBNUpe0ZNtKmMDs2OyB4yNFsRbYv/VVQkDvGSyMwwZoKmv502nUU0qkTSBJbZUf
# 8kFKP86MsWzGGB8fofNdrOom2np4Nj2wPIdKMfb0iBErFECcifFnYRs/JBpdQQTu
# KqNLkjrwuYLw9Fv5mF6W+7RZHmnhfB2QciUJPduqEcYEv+5DoF6CXwBHAncZCGl8
# uwcirg8iBOwwSTY77FRQ4deyOOUBGaxakwSuXNwVNEXI3R34eMUbv4UXf1R8Fm4O
# /5hkTr4k6+CIlHn4Jv2nZn+5SEATi1cDpIhtciAXgr/LXaeiUaPhbF7fF0xcGc2R
# NkW8ECwPsiHZlQMatqQlHEsyGK8fYVxjvdvJalOx+PemTrp+dOQ7tkl0OjgBahgl
# K84fhnEVTEo2o3jLlcUTGAJEKs5j7uld8n7inR/amAfzHMJgkpMdbMg4d9lzR36W
# 2YCQJco++SIQL7JJvgE8oB98lvp1XzThrGORz5dxEvuK6VzzYSqTYIP5Tjwt/AQb
# ULcv1A==
# SIG # End signature block
