﻿#Requires -RunAsAdministrator

<#
.SYNOPSIS
Installs and configures Keyfactor Orchestrator

.PARAMETER Source
Directory containing the files to install. Defaults to the directory containing this script.

.PARAMETER Destination
Directory where the orchestrator should be installed.
Must not be specified with -InPlace

.PARAMETER InPlace
If specified, the files will not be copied to another location, and will be configured in their current location.
Must not be specified with -Destination

.PARAMETER ServiceSuffix
Suffix of Windows Service name, after KeyfactorOrchestrator-, primarily for use if installing multiple orchestrators as Windows Services on the same machine.
Must not be specified with -NoService

.PARAMETER ServiceCredential
PSCredential object containing the username/password of the account that the service will run as. If not specified, the service will run as NT AUTHORITY\NETWORK SERVICE
Must not be specified with -NoService

.PARAMETER NoService
If specified, no Windows Service will be created. The configuration will simply be performed so the orchestrator can be manually run later. 
Must not be specified with -ServiceSuffix or -ServiceCredential

.PARAMETER OrchestratorName
Name to report as the orchestrator identifier to the Keyfactor server. If not specified, the value of the COMPUTERNAME environment variable will be used

.PARAMETER URL
URL of the Keyfactor server that this orchestrator should connect to

.PARAMETER WebCredential
PSCredential object containing the username/password that the orchestrator should use to connect to Keyfactor
Must not be specified with -ClientCertificatePemFile, -ClientCertificatePrivateKey, or -ClientCertificateThumbprint

.PARAMETER ClientCertificateThumbprint
The thumbprint that identifies a certificate with a client authentication EKU located in either the machine or service user's certificate store that will be used 
to authenticate to the Keyfactor Command server (if using client authentication). You need only supply a thumbprint or pem file/private key combination. If both 
are supplied, the certificate stores will be searched first. 
Must not be specified with -WebCredential

.PARAMETER ClientCertificate
The path to a pfx file containing the certificate that will be used to authenticate to the Keyfactor Command server (if using client authentication). You need only supply
a thumbprint or pem file/private key combination. If both are supplied, the certificate stores will be searched first. See ClientCertificateThumbprint.
Must be specified with ClientCertificatePassword
Must not be specified with -WebCredential

.PARAMETER ClientCertificatePassword
The password that should be used to access the certificate inside of the pfx provided for ClientCertificate. See ClientCertificate.

.PARAMETER Force
If specified, installation will warn and continue on certain potential conflicts (e.g. overwriting an existing install location or service name).
If this parameter is not specified, such situations will be terminating errors

.PARAMETER Capabilities
If specified, installation will include only the assemblies and manifests in accordance with the user's specification. Valid values are 'all',
'none', and 'ssl'. The default capability suite (not providing this parameter) includes all factory capabilities except for SSL Sync. 

#>

using module ".\Keyfactor.Common.InstallationCommandlets.dll"

[CmdletBinding(PositionalBinding=$false)]
Param(
    [switch]$Force,
    
    [string]$Source,
    
    [string]$Destination,
    
    [switch]$InPlace,
    
    [ValidatePattern('^[A-Za-z0-9]+$')]
    [string]$ServiceSuffix,
    
    [PSCredential]$ServiceCredential,
    
    [switch]$NoService,
    
    [ValidatePattern('^[A-Za-z0-9_\.-]+$')]
    [string]$OrchestratorName,
    
    [parameter(Mandatory,HelpMessage='URL of the Keyfactor server that this orchestrator should connect to')]
    [string]$URL,

    [parameter(Mandatory=$false,HelpMessage='PSCredential object containing the username/password that the orchestrator should use to connect to Keyfactor')]
    [PSCredential]$WebCredential,
    
    [parameter(Mandatory=$false,HelpMessage="Thumbprint of the client authentication certificate located in the machine or ServiceCredential user's certificate store")]
    [string]$ClientCertificateThumbprint,
    
    [parameter(Mandatory=$false,HelpMessage='Path to a .pfx file containing your client authentication certificate file')]
    [string]$ClientCertificate,

    [parameter(Mandatory=$false,HelpMessage='The password to the .pfx file containing your client authentication certificate file')]
    [string]$ClientCertificatePassword,

    [parameter(Mandatory=$false,HelpMessage='Specified capability suite to install. Valid values are "all", "none", and "ssl"')]
    [ValidateSet('all', 'none', 'ssl', 'default')]
    [string]$Capabilities
)

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'
$WarningPreference = 'Continue'

#Defaults
$DefaultSource = $PSScriptRoot
$DefaultDestination = 'C:\Program Files\Keyfactor\Keyfactor Orchestrator'
$DefaultServiceUser = 'NT AUTHORITY\NETWORK SERVICE'
$DefaultServiceCredential = New-Object System.Management.Automation.PSCredential ($DefaultServiceUser, (ConvertTo-SecureString 'UnusedPassword' -AsPlainText -Force))
$DefaultServiceSuffix = 'Default'
$DefaultOrchestratorName = $env:COMPUTERNAME
$CapabilityList = [System.Collections.Arraylist]@()
$MINIMUM_SUPPORTED_DOTNET_VERSION = "3.1.0.0";

# Relative paths
$RelativeOrchestratorExePath = '.\Orchestrator.exe'
$RelativeAppSettingsPath = 'configuration\appsettings.json'
$RelativeCredentialsPath = 'configuration\orchestratorsecrets.json'
$RelativeLoggingPath = '.\logs'
$RelativeScriptsPath = '.\Scripts'

$ServicePermissionGranted = $false

function Copy-KeyfactorOrchestratorFiles {
[CmdletBinding()]
Param([string]$Source,[string]$Destination,[System.Collections.ArrayList]$CapabilityList)

    if($Source -eq $Destination) {
        Write-Error "Source and Destination are both set to $Source. If you don't want to copy the files to another location, use the -InPlace flag"
    }

    Write-Verbose "Verifying existence of Keyfactor Orchestrator file in $Source"
    $orchFullPath = Join-Path $Source -ChildPath $RelativeOrchestratorExePath -Resolve

    if(-not (Test-Path $Destination)) {
        Write-Verbose "Destination path $Destination does not exist, and will be created"
        $created = md $Destination
    }

    Write-Verbose "Checking if $Destination is empty"
    $fileCount = (Get-ChildItem $Destination).Length
    if($fileCount -gt 0) {
        if($Force) {
            Write-Warning "Copying into non-empty folder '$Destination'. Files will be overwritten"

            # delete the existing items in the directory
            Get-ChildItem $Destination | Remove-Item -Recurse
            Write-Verbose "$fileCount items removed from '$Destination'"
        }
        else {
            Write-Error "Destination '$Destination' is not empty. Run again with -Force to continue copying to this location"
        }
    }
    
    # exclude the extensions directory
    Get-ChildItem $Source | Where-Object{$_.Name -notin 'extensions'} | Copy-Item -Destination $Destination -Recurse -Force

    # create the extensions directory
    if(!(Test-Path -Path "$Destination/extensions" )) {
        mkdir -p "$Destination/extensions" | Out-Null
    }

    Write-Verbose "Copying extensions to $Destination/extensions"
    foreach ($capability in $CapabilityList)
    {
        switch -Wildcard ($capability)
        {
            'CertStores.IIS*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/IIS")) {
                    Copy-Item -Path "$Source/extensions/IIS" -Destination "$Destination/extensions/IIS" -Recurse -Force
                }
            }

            'CertStores.FTP*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/FTP")) {
                    Copy-Item -Path "$Source/extensions/FTP" -Destination "$Destination/extensions/FTP" -Recurse -Force
                }
            }

            'SSL.*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/SSL")) {
                    Copy-Item -Path "$Source/extensions/SSL" -Destination "$Destination/extensions/SSL" -Recurse -Force
                }
            }

            'Custom.FetchLogs'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/FetchLogs")) {
                    Copy-Item -Path "$Source/extensions/FetchLogs" -Destination "$Destination/extensions/FetchLogs" -Recurse -Force
                }
            }

            'CA.*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/CertificateAuthority")) {
                    Copy-Item -Path "$Source/extensions/CertificateAuthority" -Destination "$Destination/extensions/CertificateAuthority" -Recurse -Force
                }
            }
        }
    }

    # we should always copy the generic extensions
    if (-not (Test-Path -Path "$Destination/extensions/JobExtensionDrivers")) {
        Copy-Item -Path "$Source/extensions/JobExtensionDrivers" -Destination "$Destination/extensions/JobExtensionDrivers" -Recurse -Force
    }
}

function Join-Url {
Param([Parameter(Mandatory=$true)][string]$BaseUrl,
    [Parameter(Mandatory=$true)][string]$RelativeUrl)

    return "$($BaseUrl.TrimEnd('/'))/$($RelativeUrl.TrimStart('/'))"
}

# Force basic auth which cannot be done with Invoke-WebRequest
function Invoke-WebRequestBasic {
[CmdletBinding()]
Param([Parameter(Mandatory=$true)][string]$URL,
    [Parameter(Mandatory=$true)][PSCredential]$Credential)

    $cache = New-Object System.Net.CredentialCache
    $cache.Add($URL, 'Basic', $Credential.GetNetworkCredential())

    $request = [Net.WebRequest]::CreateHttp($URL)
    $request.Credentials = $cache

    $response = $request.GetResponse()

    return $response
}

function Add-KeyfactorConfigurationValue {
[CmdletBinding()]
Param([Parameter(Mandatory, ValueFromPipeline)][Hashtable]$InputObject,
    [Parameter(Mandatory=$true)][string]$Key,
    $Value)

    $keyParts = $Key.Split(':')

    $cursor = $InputObject
    for($i = 0; $i -lt ($keyParts.Count-1); $i++) {
        
        if(-not $cursor[$keyParts[$i]]) {
            $cursor[$keyParts[$i]] = @{}
        }

        $cursor = $cursor[$keyParts[$i]]
    }

    $cursor[$keyParts[-1]] = $Value

    return $InputObject
}

# Since versions before 7 don't have -AsHashTable option on ConvertFrom-Json
# From https://stackoverflow.com/a/34383464/1238851
function Convert-PSObjectToHashtable
{
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process
    {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string])
        {
            $collection = @(
                foreach ($object in $InputObject) { Convert-PSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject])
        {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash[$property.Name] = Convert-PSObjectToHashtable $property.Value
            }

            $hash
        }
        else
        {
            $InputObject
        }
    }
}

function Validate-KeyfactorOrchestratorAuthenticationMethod {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string]$URL,
    
    [Parameter(Mandatory=$false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory=$false)]
    [string]$Thumbprint,

    [Parameter(Mandatory=$false)]
    [string]$Certificate,

    [Parameter(Mandatory=$false)]
    [string]$CertificatePassword
)

    if ($Credential -ne $null)
    {
        Write-Verbose "Validating URL '$URL' and credentials for '$($Credential.UserName)'"
        $statusResp = Invoke-WebRequestBasic -URL (Join-Url $URL 'Session/Status') -Credential $Credential
    }

    if (![string]::IsNullOrEmpty($Thumbprint)) {
        Write-Verbose "Validating URL '$URL' and client auth certificate with thumbprint '$Thumbprint'"
        Write-Verbose "Searching machine store for certificate with thumbprint '$Thumbprint'"
       
        $cert = Get-Item -Path Cert:\LocalMachine\MY\$Thumbprint -ErrorAction SilentlyContinue

        if ($cert -eq $null) {
            Write-Verbose "Certificate with thumbprint '$Thumbprint' was not found in the machine store. Searching the executing user store"          
            $cert = Get-Item -Path Cert:\CurrentUser\MY\$Thumbprint -ErrorAction SilentlyContinue
            if ($cert -ne $null) {
                Write-Warning "The certificate will need to reside in the Personal store of the account that is running the installed service"
            }
        }

        if ($cert -eq $null) {
            Write-Error "Unable to locate a certificate with thumbprint '$Thumbprint' in the personal store of the machine or current user"
        }
        else
        {
            Write-Verbose "Certificate found"
        }

        $statusResp = Keyfactor.Common.InstallationCommandlets\Test-Connection -Uri (Join-Url $URL 'Session/Status') -Certificate $cert
    }

    if (![string]::IsNullOrEmpty($Certificate) -and ![string]::IsNullOrEmpty($CertificatePassword)) {
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $cert.Import($Certificate, $CertificatePassword, 'EphemeralKeySet')

        $statusResp = Keyfactor.Common.InstallationCommandlets\Test-Connection -Uri (Join-Url $URL 'Session/Status') -Certificate $cert
    }
}

function Set-KeyfactorOrchestratorConfiguration {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string]$InstallDir,
    
    [Parameter(Mandatory=$false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory=$false)]
    [string]$Thumbprint,

    [Parameter(Mandatory=$false)]
    [string]$Certificate,

    [Parameter(Mandatory=$false)]
    [string]$CertificatePassword,

    [string]$OrchestratorName
)

    if(-not $OrchestratorName) {
        Write-Verbose "OrchestratorName not expicitly set. Defaulting to $env:COMPUTERNAME"
        $OrchestratorName = $env:COMPUTERNAME
    }

    Write-Verbose 'Computing configuration file paths'
    $credsPath = Join-Path $InstallDir $RelativeCredentialsPath
    $appSettingsPath = Join-Path $InstallDir $RelativeAppSettingsPath

    if ($Credential -ne $null) {
        Write-Verbose "Saving credentials to '$credsPath'"
        $credsFileContent = @{'Secrets' = @{'Username' = $Credential.UserName; 'Password' = $Credential.GetNetworkCredential().Password}}
        ConvertTo-Json $credsFileContent | Set-Content $credsPath
    }

    if (![string]::IsNullOrEmpty($Thumbprint)) {
        # TODO - ConvertTo-Json makes quite ugly JSON, and will trip if someone adds a comment. Consider using Newtonsoft.Json (fairly low risk as it doesn't have dependencies)
        Write-Verbose "Saving client certificate thumbprint to '$appSettingsPath'"
        Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
            Add-KeyfactorConfigurationValue -Key 'AppSettings:AuthCertThumbprint' -Value $Thumbprint |
            ConvertTo-Json | Set-Content $appSettingsPath
    }

    if (![string]::IsNullOrEmpty($Certificate) -and ![string]::IsNullOrEmpty($CertificatePassword)) {
        Write-Verbose "Saving client certificate password to '$credsPath'"
        $credsFileContent = @{'Secrets' = @{'ClientAuthCertificatePassword' = $CertificatePassword; }}
        ConvertTo-Json $credsFileContent | Set-Content $credsPath

        Write-Verbose "Saving client certificate file path to '$appSettingsPath'"
        Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
            Add-KeyfactorConfigurationValue -Key 'AppSettings:CertPath' -Value $Certificate |
            ConvertTo-Json | Set-Content $appSettingsPath
    }

    Write-Verbose "Restricting ACL for $credsPath"
    $credAcl = Get-Acl -Path $credsPath
    $credAcl.SetSecurityDescriptorSddlForm('D:PAI(A;;FA;;;BA)', 'Access') # Restrict to only built-in admins
    Set-Acl -Path $credsPath -AclObject $credAcl

    Write-Verbose "Saving to '$appSettingsPath'"
    Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
        Add-KeyfactorConfigurationValue -Key 'AppSettings:AgentsServerUri' -Value $URL |
        Add-KeyfactorConfigurationValue -Key 'AppSettings:OrchestratorName' -Value $OrchestratorName |
        ConvertTo-Json | Set-Content $appSettingsPath
}

function Add-PermissionToFile {
[CmdletBinding()]
Param([string]$Path, [string]$User, [System.Security.AccessControl.FileSystemRights]$Rights)

    $acl = Get-Acl -Path $Path
    Write-Verbose "Granting rights $Rights to $User on $Path"

    if(Test-Path -Path $Path -PathType Container) {
        $acl.AddAccessRule((New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList ($User, $Rights, 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
    }
    else {
        $acl.AddAccessRule((New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList ($User, $Rights, 'Allow')))
    }

    Set-Acl -Path $Path -AclObject $acl
}

function Validate-PermissionOnFile {
[CmdletBinding()]
Param([string]$Path, [string]$User, [System.Security.AccessControl.FileSystemRights]$Rights)
    return (Get-Acl $Path).Access | 
                ?{$_.IdentityReference -eq $User} | 
                ?{($_.FileSystemRights -band $Rights) -eq $Rights}
}

function Grant-LogOnAsAServicePermission {
[CmdletBinding()]
Param([string]$User)
    try 
    {
		Set-LsaPermission -Username $User -Permission "SeServiceLogonRight"
        $ServicePermissionGranted = $true;
    } 
    catch 
    {
       Write-Warning "Failed to grant Log on as a Service permission to user $($User). "
    }
}

# Find linked services by name or path and remove them
function Remove-LinkedKeyfactorOrchestratorServices {
[CmdletBinding()]

	$servicePath = Join-Path $InstallDir -ChildPath $RelativeOrchestratorExePath -Resolve -ErrorAction SilentlyContinue
	$shortName = "KeyfactorOrchestrator-$ServiceSuffix"

	if ($servicePath)
	{
		$cimServicesByPath = Get-KeyfactorOrchestratorServiceByPath $servicePath

		if ($cimServicesByPath) 
		{
			$serviceAlreadyInstalled = "$($cimServicesByPath.Name) is already installed using the executable at $servicePath."
			Uninstall-KeyfactorOrchestratorServices -Services $cimServicesByPath -WarningMessage $serviceAlreadyInstalled
		}
	}

	if (-not $NoService)
	{
		$cimServicesByName = Get-KeyfactorOrchestratorServiceByName $shortName

		if ($cimServicesByName)
		{
			$serviceAlreadyInstalled = "$($cimServicesByName.Name) is already the name of an installed service."
			Uninstall-KeyfactorOrchestratorServices -Services $cimServicesByName -WarningMessage $serviceAlreadyInstalled
		}
	}
}

function Uninstall-KeyfactorOrchestratorServices {
[CmdletBinding()]
Param([object[]]$Services,
    [string]$WarningMessage)

	if($Force)
	{
        ForEach ($service in $Services)
        {
            $serviceName = $service.Name
			Write-Warning "$WarningMessage The existing service will be removed"

			Write-Verbose "Removing existing service $serviceName"
			Stop-Service $serviceName
			Start-Process -FilePath "sc.exe" -ArgumentList "delete $serviceName" -Wait
        }
	}
	else
	{
		Write-Error "$WarningMessage Retry with the -Force flag to overwrite the existing service"
	}
}

function Install-KeyfactorOrchestratorService {
[CmdletBinding()]
Param([string]$ServiceSuffix,
    [PSCredential]$ServiceCredential,
    [string]$InstallDir)

    $shortName = "KeyfactorOrchestrator-$ServiceSuffix"
    $displayName = "Keyfactor Orchestrator Service ($ServiceSuffix)"
    $description = 'Service to perform any remote orchestrator jobs for Keyfactor.'
    $appSettingsPath = Join-Path $InstallDir -ChildPath $RelativeAppSettingsPath -Resolve
    $credentialInUse = $DefaultServiceCredential

    Write-Verbose 'Resolving ServicePath'
    $ServicePath = Join-Path $InstallDir -ChildPath $RelativeOrchestratorExePath -Resolve

    Write-Verbose "Creating new service $shortName"
    $serviceParams = @{
        Name = $shortName;
        BinaryPathName = $ServicePath;
        StartupType = 'Automatic';
        Credential = $ServiceCredential;
        DisplayName = $displayName;
        Description = $description
    }

    
    if($ServiceCredential.UserName.EndsWith('$'))
    {
        $serviceParams['Credential'] = $DefaultServiceCredential
    }

    Write-Verbose "Creating service to run as $($serviceParams['Credential'].UserName)"
    $service = New-Service @serviceParams

    if($ServiceCredential.UserName.EndsWith('$'))
    {
        Write-Verbose "Modifying service to run as $($ServiceCredential.UserName)"
        $serviceObject = Get-CimInstance -ClassName Win32_Service -Filter "name='$shortName'"

        $cimArgs = @{'StartName'= $ServiceCredential.UserName}
        $cimResult = Invoke-CimMethod -InputObject $serviceObject -MethodName Change -Arguments $cimArgs
        
        if($cimResult.ReturnValue -ne 0)
        {
            Write-Warning "Attempt to modify service to run as $($ServiceCredential.UserName) returned $($cimResult.ReturnValue). Change may not have been successful"
        }
    }


    Write-Verbose "Granting necessary file permissions to $($ServiceCredential.UserName)"
    Add-PermissionToFile -Path (Join-Path $InstallDir -ChildPath $RelativeCredentialsPath -Resolve) -User $ServiceCredential.UserName -Rights Modify
    Add-PermissionToFile -Path (Join-Path $InstallDir -ChildPath $RelativeLoggingPath -Resolve) -User $ServiceCredential.UserName -Rights Modify

    if ($ServiceCredential -ne $DefaultServiceCredential) 
    {
        Write-Information "Granting necessary file permissions to $($ServiceCredential.UserName) for configuration file"
        Add-PermissionToFile -Path $appSettingsPath -User $ServiceCredential.UserName -Rights Modify

        Write-Information "Granting Log on as a Service permission to $($ServiceCredential.UserName)"
        Grant-LogOnAsAServicePermission -User $ServiceCredential.UserName 

        $credentialInUse = $ServiceCredential
    }
    else
    {
        Write-Information "Granting necessary file permissions to $($DefaultServiceUser) for configuration file"
        Add-PermissionToFile -Path $appSettingsPath -User $DefaultServiceUser -Rights Modify        
    }

    if (!$(Validate-PermissionOnFile -Path $appSettingsPath -User $credentialInUse.UserName -Rights Modify))
    {
        Write-Error "User $($credentialInUse.UserName) does not have modify permissions on $appSettingsPath"
    }

    Write-Information "Starting service $shortName"
    try
    {
		Start-Service -Name $shortName
    }
    catch
    {
        # Warn the user specifically that the service permission was not granted. Most likely the fix to the thrown exception
        if (!$ServicePermissionGranted)
        {
            Write-Warning "Unable to start the service $shortName. Manually grant the Log on as a Service permission and restart the service."
        }

		Write-Error $error[0]
    }
}

function Get-KeyfactorOrchestratorServiceByName {
[CmdletBinding()]
Param([Parameter(Mandatory=$true)][string]$ServiceName)

    Write-Verbose "Checking for existing services with name '$ServiceName'"
    $cimServices = @(Get-CimInstance Win32_Service -Filter "Name='$ServiceName'")

    Write-Verbose "$($cimServices.Count) services found with name '$ServiceName'"

    return $cimServices
}

function Get-KeyfactorOrchestratorServiceByPath {
[CmdletBinding()]
Param([Parameter(Mandatory=$true)][string]$ServicePath)

    Write-Verbose "Checking for existing services at path '$ServicePath'"  # Easier to cast a wider net and filter in PS than it is to make a precise WQL query
    $cimServices = @(Get-CimInstance Win32_Service -Filter "PathName LIKE '%$(Split-Path -Leaf $ServicePath)%'" | where -FilterScript {$_.PathName.Trim('"') -eq $ServicePath})

    Write-Verbose "$($cimServices.Count) services found at path '$servicePath'"

    return $cimServices
}

function Resolve-Capabilities {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string] $Capabilities,
    [Parameter(Mandatory=$true)][AllowEmptyCollection()][System.Collections.ArrayList]$CapabilityList
)
    $CapabilityList.Add("CertStores.IIS.Inventory") | Out-Null
    $CapabilityList.Add("CertStores.FTP.Inventory") | Out-Null
    $CapabilityList.Add("CertStores.IIS.Reenrollment") | Out-Null
    $CapabilityList.Add("CertStores.F5.Reenrollment") | Out-Null
    $CapabilityList.Add("CertStores.F5.Inventory") | Out-Null
    $CapabilityList.Add("CA.Certificates") | Out-Null
    $CapabilityList.Add("CertStores.F5.Management") | Out-Null
    $CapabilityList.Add("CertStores.IIS.Management") | Out-Null
    $CapabilityList.Add("CA.Templates") | Out-Null
    $CapabilityList.Add("Custom.FetchLogs") | Out-Null
    $CapabilityList.Add("CertStores.FTP.Management") | Out-Null

    if ($Capabilities -eq 'ssl') { 
        $CapabilityList.Clear()
        $CapabilityList.Add("SSL.Discovery") | Out-Null
        $CapabilityList.Add("SSL.Monitoring") | Out-Null
    }

    if ($Capabilities -eq 'all') {
        $CapabilityList.Add("SSL.Discovery") | Out-Null
        $CapabilityList.Add("SSL.Monitoring") | Out-Null
    }

    if ($Capabilities -eq 'none') {
        $CapabilityList.Clear()
    }
}

function Set-EventLogCategories {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string] $Destination
)
    $RegistryPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Application\Keyfactor Orchestrator'
    $MessageFilePath = "$Destination\CSS.CMS.EventLogCategories.dll"
    
    # Now set the value
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'CategoryCount' -Value '27' -Type 'DWORD'
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'TypesSupported' -Value '7' -Type 'DWORD'
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'CategoryMessageFile' -Value $MessageFilePath -Type 'ExpandString'
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'EventMessageFile' -Value "$MessageFilePath;C:\Windows\Microsoft.NET\Framework64\v4.0.30319\EventLogMessages.dll" -Type 'ExpandString'
}

function Set-RegistryValue {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string] $RegistryPath,
    [Parameter(Mandatory=$true)][string] $Name,
    [Parameter(Mandatory=$true)][string] $Value,
    [Parameter(Mandatory=$true)][string] $Type
)
    # Create the key if it does not exist
    If (-NOT (Test-Path $RegistryPath)) {
      New-Item -Path $RegistryPath -Force | Out-Null
    }  

    # Now set the value
    New-ItemProperty -Path $RegistryPath -Name $Name -Value $Value -PropertyType $Type -Force 
}

# MAIN

Write-Verbose 'Checking for .NET Core Runtime 3.1 or greater'
$minimumSupportedVersionFound = $false
if (Get-Command -Name dotnet -ErrorAction SilentlyContinue) {
    $minimumVersion = New-Object -TypeName System.Version -ArgumentList "$MINIMUM_SUPPORTED_DOTNET_VERSION"
    dotnet --list-runtimes | Select-String -Pattern "Microsoft.NETCore.App *" | ForEach-Object {
        $systemVersion = New-Object -TypeName System.Version -ArgumentList "$($_.Line.Split(' ')[1]).0"
        if ($systemVersion -ge $minimumVersion)
        {
            $minimumSupportedVersionFound = $true
            # you can't break inside of this method or PowerShell interprets it as an error
        }
    }
}

if (!$minimumSupportedVersionFound) {
    Write-Error ".NET Core Runtime version $MINIMUM_SUPPORTED_DOTNET_VERSION or later was not found. Please ensure this runtime is installed"
}

Write-Verbose 'Validating parameters'
# if no method of authentication is supplied, we will assume that they want to be prompted for credentials
if ($WebCredential -eq $null -and [string]::IsNullOrEmpty($ClientCertificateThumbprint) -and [string]::IsNullOrEmpty($ClientCertificate)) {
    $WebCredential = Get-Credential   
}

#ensure client auth certificate exists
if ($WebCredential -ne $null -and ![string]::IsNullOrEmpty($ClientCertificateThumbprint) -or $WebCredential -ne $null -and ![string]::IsNullOrEmpty($ClientCertificate)) {
    Write-Error 'Web credentials cannot be specified with a client certificate'
}

if (![string]::IsNullOrEmpty($ClientCertificate) -and [string]::IsNullOrEmpty($ClientCertificatePassword)) {
    Write-Error 'A client certificate pfx was provided without a password.'
}

if($Destination -and $InPlace) {
    Write-Error '-Destination and -InPlace cannot both be specified'
}
if($NoService -and ($ServiceSuffix -or $ServiceCredential)) {
    Write-Error '-NoService cannot be specified with -ServiceSuffix or -ServiceCredential'
}

if($InPlace -and $Capabilities -ne 'all') {
    Write-Error '-InPlace can only be used with capability handling suite "all"'
}

Write-Verbose 'Configuring defaults for unset parameters'
if(-not $Source) {
    Write-Verbose "Source is not explicitly set. Defaulting to $DefaultSource"
    $Source = $DefaultSource
}
if(-not $Destination) {
    Write-Verbose "Destination is not explicitly set. Defaulting to $DefaultDestination"
    $Destination = $DefaultDestination
}
if($InPlace) {
    $InstallDir = $Source
}
else {
    $InstallDir = $Destination
}

if(-not $ServiceCredential) {
    Write-Verbose "Service credential is not explicitly set. Defaulting to $($DefaultServiceCredential.UserName)"
    $ServiceCredential = $DefaultServiceCredential
}
if(-not $ServiceSuffix) {
    Write-Verbose "Service suffix is not explicitly set. Defaulting to $DefaultServiceSuffix"
    $ServiceSuffix = $DefaultServiceSuffix
}
if(-not $OrchestratorName) {
    Write-Verbose "Orchestrator name is not explicitly set. Defaulting to $DefaultOrchestratorName"
    $OrchestratorName = $DefaultOrchestratorName
}

if (-not $Capabilities) {
    Write-Verbose "Capability handling is not explicitly set. Defaulting to 'default'"
    $Capabilities = 'default'
}

# Services that reference the existing files will need to be removed before clearing the directory
Remove-LinkedKeyfactorOrchestratorServices

if(-not $InPlace) {
    Write-Information 'Copying files'
    Resolve-Capabilities $Capabilities $CapabilityList
    Copy-KeyfactorOrchestratorFiles $Source $Destination $CapabilityList
}

# create the logs directory
if(!(Test-Path -Path "$InstallDir/$RelativeLoggingPath" )) {
	Write-Verbose "Creating log directory"
	mkdir -p "$InstallDir/$RelativeLoggingPath" | Out-Null
}

# create the Scripts directory
if(!(Test-Path -Path "$InstallDir/$RelativeScriptsPath" )) {
	Write-Verbose "Creating Scripts directory"
	mkdir -p "$InstallDir/$RelativeScriptsPath" | Out-Null
}

Write-Information 'Setting configuration data'
if ($WebCredential -ne $null){
    Validate-KeyfactorOrchestratorAuthenticationMethod -URL $URL -Credential $WebCredential
    Set-KeyfactorOrchestratorConfiguration -InstallDir $InstallDir -Credential $WebCredential -OrchestratorName $OrchestratorName
}

if (![string]::IsNullOrEmpty($ClientCertificateThumbprint))
{
    Validate-KeyfactorOrchestratorAuthenticationMethod -URL $URL -Thumbprint $ClientCertificateThumbprint
    Set-KeyfactorOrchestratorConfiguration -InstallDir $InstallDir -Thumbprint $ClientCertificateThumbprint -OrchestratorName $OrchestratorName
}

if (![string]::IsNullOrEmpty($ClientCertificate))
{
    Validate-KeyfactorOrchestratorAuthenticationMethod -URL $URL -Certificate $ClientCertificate -CertificatePassword $ClientCertificatePassword
    Set-KeyfactorOrchestratorConfiguration -InstallDir $InstallDir -Certificate $ClientCertificate -CertificatePassword $ClientCertificatePassword -OrchestratorName $OrchestratorName
}

if(-not $NoService) {
    Write-Information 'Installing Windows Service'
    Install-KeyfactorOrchestratorService -InstallDir $InstallDir -ServiceSuffix $ServiceSuffix -ServiceCredential $ServiceCredential
}
else
{
    Write-Warning '-NoService was specified. Your client authentication private key or WebCredential password will not be encrypted until the executable is started.'
}

Write-Verbose 'Updating event log categories in registry'
Set-EventLogCategories -Destination $Destination

# SIG # Begin signature block
# MIIpPwYJKoZIhvcNAQcCoIIpMDCCKSwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBdb8dON4uhmnyI
# jE9K9O0IhWdEP89Sgs01zTY2lHeIOqCCDi4wggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggd2MIIFXqADAgECAhAPhranjL3m2+B++PUunMN2MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjMwMTMxMDAwMDAwWhcNMjQwMTMw
# MjM1OTU5WjB7MQswCQYDVQQGEwJVUzENMAsGA1UECBMET2hpbzEVMBMGA1UEBxMM
# SW5kZXBlbmRlbmNlMRcwFQYDVQQKEw5LZXlmYWN0b3IsIEluYzEUMBIGA1UECxML
# RW5naW5lZXJpbmcxFzAVBgNVBAMTDktleWZhY3RvciwgSW5jMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEA6eKOGZEUVtAocGpTHAy1/Bgxl1tOWPqdFzFG
# 0w8K+3gGUOB985b+uGJTB6bxYdwtUJcsmZ3cSwSKYbWJBPswivciR9exow7R4asM
# Fz2tSuLkHNEdOg6A5h3Cgl26t3LdEKS/SWNWnhS9GI1r+Cb2B/9/ptJ3fsaR8Z94
# qOz1YfjSK0kxRRABzi6GsP9OXikmFe4ubbnd347B7dTShJFtKhQPhIMOn+ac3YcI
# Jac3+5m7KiLSD6M+hdPS0v1jhBiyn0sS4zrVLrL7IAkNj3mhFCtg2U5Z+Xr4kH+z
# pbfp2v71lyErlVWb5WwdJjGEOo/LSfHZZbwIReZtt2p7R5DCUmFd7ScYimW5+lhK
# 8NGrdvsR4xIWRSBhRBus6t3fnWDhvvDebSKAzC2E39xwqjtiA5hmIF5lrDujOoTK
# dOnnApR55/moQ1GYQX5mAK0rKs90u+PGMEvAG8+E88wm+kXZJswlfJr3Y0nJ7kiA
# t1szJOMU5D8EM1DnSsFqCPWnwgGSgjSOzKebFrYHf7Fs33XmTSwOkusi4iq0bx7G
# WKoKVVZKl1KqN3Wunratgna+GLgdLJA86aBx0HFD8YLM3JlhjnAlxEGtKRiYXpq7
# VyfL7RyR8jcjqnmnynzCEdnNvKZNPQKkc21lQj1okw8ulxMiwceK1I9soK0joWk9
# uvJIVy0CAwEAAaOCAgYwggICMB8GA1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl
# 9E5CMB0GA1UdDgQWBBRFBxQUF8Mbu1SWiMft7H5L5JJc/zAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCBqjBToFGgT4ZNaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25p
# bmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0dHA6Ly9jcmw0LmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNI
# QTM4NDIwMjFDQTEuY3JsMD4GA1UdIAQ3MDUwMwYGZ4EMAQQBMCkwJwYIKwYBBQUH
# AgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzCBlAYIKwYBBQUHAQEEgYcw
# gYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEF
# BQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAU66XgPDhk2SpLMNQtdTMn//V5Xq3Sh7E
# xctsMkQ7BjHBg7ngpmQ8iNSGCfgmQgEp3r4FGKxVegtAwOiOOLzz3VSwCl4mN+Dv
# NauYHHmR2/YGlJKVKnYqVf7WS00dBNOYrh2p5sz+ZjI1vVaBJf8/MHN7r3eKDjyr
# PlH2S3VAivFyUMYbSrCsxJcRBDdCgq2EeKJkYz2mCIV6F0LGqzuse/5CXWCbG4BP
# cMGNX+sd6CZ0SZ7RLfPLSz/d5u6L5G2w4uHPp2gSNXUw90C8q+nxCHDCzJFmXwJu
# DhUchPgcb6Nm5bNawBVrV7VlHP0KoxSTWemB4Xs8axuJ+I1gwrhow1G/EKgD1J0A
# 5+plRlwvVTomIp8empYpNAJfmLKgvEPKHjVaFoeQ0qxlNEixp4YD4wZO0U8cYhH2
# 0wFcEAR+jcxyv5VWWGMj4JMcdC6YorUxG/29U8fG48GldCEz5gkJ4mhbOF11RfR5
# QffkblniZZ7+qZrzQOkMTfGWAI638uDXgCOaejQDoeCKRz6iNbXNpj/fcB7e1Omg
# vmfKK0Ca2kC8PLSiIP5JPmFmplS/5Y136w0JRld18pbgmbTPLzfgSKCGAH5RGa9K
# C5SGS+JUhMJ6MxTKc97dXfhZaE4KUjiKQj2iLPnXm1AZDkt4C9coxnKbwbFic0Bw
# uSelnVg6avcxghpnMIIaYwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5E
# aWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2Rl
# IFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTECEA+GtqeMvebb4H749S6c
# w3YwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3AgEMMQIwADAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQgFkSi//KU08INmroYJ4DL1h2xsuXcUgfGQSojcfP7E38w
# DQYJKoZIhvcNAQEBBQAEggIAvlHJfhoimN5xNpqNxLZ3ZXV8aRaE3v8x4SFIcU1e
# VdFVzyEoOSIEgWt5fbhXhIX2FjAFKlkmZ1ikUmok6O8wSGU1np3YXm1G4wnuDRs/
# 5qhVImEEL0nHrspqG7jjFuAXj+dVhzrWq8mw5qYp1DX0KTN9vcckvnpcpQlyRS3v
# G7KfGfsaJNWyqXNMui5zs74Uv2ew992wsw7nDkbFY5n6vcB38tdC7uuHibDpCgdA
# oscVv+tYIhg3FbaAdExHJbaiuNeNBTLjcEomni9mU0TbYnJsJFnpE+OBvhsHtjy3
# +zLwnSxipdjXdhEhrnCS9yTN8T7bEFry63UKEXYJclHXSBZf7Oun6K6+GvFandPW
# vMZU+IpO93bdmBj3Iq+yPLeQa68YMitOUOFOQKk0YNSSlzgyyYNQK6quzXJKSlgb
# xdSsC7EKvCGm5QZh8hI2g1TCNFPlNfuThTcrPao9wSoxsilL+afEzJ0S8gMSJJJ2
# 3yJGoJfoSrZPIQ1pVrfPBCGki45UmTScVWv+4la1+TQ3jNiyIsfJG9H4y0atj2FE
# fTyx2gEgqTybGFVuOP3tmF1N6sIZtH/veKZS8M65qcOu7d8CPLWhnYfVOY8ph8Bd
# RJcDvJDWepXzQXlY06m4oc9k7oJK4Vz7GUuADnEpXavd84EUONVceFEHPTL+mhwX
# ck2hghc9MIIXOQYKKwYBBAGCNwMDATGCFykwghclBgkqhkiG9w0BBwKgghcWMIIX
# EgIBAzEPMA0GCWCGSAFlAwQCAQUAMHcGCyqGSIb3DQEJEAEEoGgEZjBkAgEBBglg
# hkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgGM3zszYdX7ewq2BTwoQu6yp2LrM+
# Zq5BRlFa3j3p3ewCEGIyKbd28w+lF/yPFInDMq0YDzIwMjMwNDA3MTUyOTQyWqCC
# EwcwggbAMIIEqKADAgECAhAMTWlyS5T6PCpKPSkHgD1aMA0GCSqGSIb3DQEBCwUA
# MGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UE
# AxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBp
# bmcgQ0EwHhcNMjIwOTIxMDAwMDAwWhcNMzMxMTIxMjM1OTU5WjBGMQswCQYDVQQG
# EwJVUzERMA8GA1UEChMIRGlnaUNlcnQxJDAiBgNVBAMTG0RpZ2lDZXJ0IFRpbWVz
# dGFtcCAyMDIyIC0gMjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAM/s
# pSY6xqnya7uNwQ2a26HoFIV0MxomrNAcVR4eNm28klUMYfSdCXc9FZYIL2tkpP0G
# gxbXkZI4HDEClvtysZc6Va8z7GGK6aYo25BjXL2JU+A6LYyHQq4mpOS7eHi5ehbh
# VsbAumRTuyoW51BIu4hpDIjG8b7gL307scpTjUCDHufLckkoHkyAHoVW54Xt8mG8
# qjoHffarbuVm3eJc9S/tjdRNlYRo44DLannR0hCRRinrPibytIzNTLlmyLuqUDgN
# 5YyUXRlav/V7QG5vFqianJVHhoV5PgxeZowaCiS+nKrSnLb3T254xCg/oxwPUAY3
# ugjZNaa1Htp4WB056PhMkRCWfk3h3cKtpX74LRsf7CtGGKMZ9jn39cFPcS6JAxGi
# S7uYv/pP5Hs27wZE5FX/NurlfDHn88JSxOYWe1p+pSVz28BqmSEtY+VZ9U0vkB8n
# t9KrFOU4ZodRCGv7U0M50GT6Vs/g9ArmFG1keLuY/ZTDcyHzL8IuINeBrNPxB9Th
# vdldS24xlCmL5kGkZZTAWOXlLimQprdhZPrZIGwYUWC6poEPCSVT8b876asHDmoH
# OWIZydaFfxPZjXnPYsXs4Xu5zGcTB5rBeO3GiMiwbjJ5xwtZg43G7vUsfHuOy2SJ
# 8bHEuOdTXl9V0n0ZKVkDTvpd6kVzHIR+187i1Dp3AgMBAAGjggGLMIIBhzAOBgNV
# HQ8BAf8EBAMCB4AwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwHwYDVR0jBBgwFoAU
# uhbZbU2FL3MpdpovdYxqII+eyG8wHQYDVR0OBBYEFGKK3tBh/I8xFO2XC809KpQU
# 31KcMFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFRydXN0ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5jcmww
# gZAGCCsGAQUFBwEBBIGDMIGAMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wWAYIKwYBBQUHMAKGTGh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFRydXN0ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5j
# cnQwDQYJKoZIhvcNAQELBQADggIBAFWqKhrzRvN4Vzcw/HXjT9aFI/H8+ZU5myXm
# 93KKmMN31GT8Ffs2wklRLHiIY1UJRjkA/GnUypsp+6M/wMkAmxMdsJiJ3HjyzXyF
# zVOdr2LiYWajFCpFh0qYQitQ/Bu1nggwCfrkLdcJiXn5CeaIzn0buGqim8FTYAno
# o7id160fHLjsmEHw9g6A++T/350Qp+sAul9Kjxo6UrTqvwlJFTU2WZoPVNKyG39+
# XgmtdlSKdG3K0gVnK3br/5iyJpU4GYhEFOUKWaJr5yI+RCHSPxzAm+18SLLYkgyR
# TzxmlK9dAlPrnuKe5NMfhgFknADC6Vp0dQ094XmIvxwBl8kZI4DXNlpflhaxYwzG
# RkA7zl011Fk+Q5oYrsPJy8P7mxNfarXH4PMFw1nfJ2Ir3kHJU7n/NBBn9iYymHv+
# XEKUgZSCnawKi8ZLFUrTmJBFYDOA4CPe+AOk9kVH5c64A0JH6EE2cXet/aLol3RO
# LtoeHYxayB6a1cLwxiKoT5u92ByaUcQvmvZfpyeXupYuhVfAYOd4Vn9q78KVmksR
# AsiCnMkaBXy6cbVOepls9Oie1FqYyJ+/jbsYXEP10Cro4mLueATbvdH7WwqocH7w
# l4R44wgDXUcsY6glOJcB0j862uXl9uab3H4szP8XTE0AotjWAQ64i+7m4HJViSwn
# GWH2dwGMMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0oZipeWzANBgkqhkiG9w0B
# AQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVk
# IFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIyMjM1OTU5WjBjMQswCQYD
# VQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lD
# ZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1BkmzwT1ySVFVxyUDxPKR
# N6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3znIkLf50fng8zH1ATCyZz
# lm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZKz5C3GeO6lE98NZW1Oco
# LevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald68Dd5n12sy+iEZLRS8nZH
# 92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zkpsUdzTYNXNXmG6jBZHRA
# p8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYnLvWHpo9OdhVVJnCYJn+g
# GkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIqx5K/oN7jPqJz+ucfWmyU
# 8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOdOqPVA+C/8KI8ykLcGEh/
# FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJTYsg0ixXNXkrqPNFYLwj
# jVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJRk8mMDDtbiiKowSYI+RQQ
# EgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEoAA6EVO7O6V3IXjASvUae
# tdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1UdEwEB/wQIMAYBAf8CAQAw
# HQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8GA1UdIwQYMBaAFOzX44LS
# cV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEF
# BQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRp
# Z2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDwwOjA4oDagNIYy
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5j
# cmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEB
# CwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0TzzBTzr8Y+8dQXeJLKftw
# ig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYSlm/EUExiHQwIgqgWvalW
# zxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaqT5Fmniye4Iqs5f2MvGQm
# h2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl2szwcqMj+sAngkSumScb
# qyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1yr8THwcFqcdnGE4AJxLaf
# zYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05et3/JWOZJyw9P2un8WbD
# Qc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6umAU+9Pzt4rUyt+8SVe+0K
# XzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSweJywm228Vex4Ziza4k9Tm
# 8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr7ZVBtzrVFZgxtGIJDwq9
# gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYCJtnwZXZCpimHCUcr5n8a
# pIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzgaoSv27dZ8/DCCBY0wggR1
# oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAwZTELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4X
# DTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1OVowYjELMAkGA1UEBhMCVVMxFTAT
# BgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEh
# MB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUuySE98orYWcLh
# Kac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR0uRf1gU8Ug9SH8aeFaV+
# vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7fgvMHhOZ0O21x4i0MG+4g1ckgHWMp
# Lc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEioZldXn1RYjgwrt0+n
# MNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raRmECQecN4x7axxLVqGDgDEI3Y1Dek
# LgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFEmjNAvwjXWkmk
# wuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2mHY9WV1CdoeJl2l6SPDgohIbZpp0
# yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXfSwQAzH0clcOP
# 9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaAsPvoZKYz0YkH4b235kOkGLimdwHh
# D5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ6zHFynIWIgnf
# fEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCPorF+CiaZ9eRpL5gdLfXZqbId
# 5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFOzX44LS
# cV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgP
# MA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0
# dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2Vy
# dHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDBFBgNV
# HR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRB
# c3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQKMAgwBgYEVR0gADANBgkqhkiG9w0B
# AQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVeqRq7IviHGmlU
# Iu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy3iS8UgPITtAq3votVs/59PesMHqa
# i7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum6fI0POz3A8eH
# qNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxUjG/voVA9/HYJaISfb8rbII01
# YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2zm8jLfR+cWojayL/ErhULSd+2DrZ
# 8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDGCA3YwggNyAgEBMHcwYzELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2Vy
# dCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQQIQDE1p
# ckuU+jwqSj0pB4A9WjANBglghkgBZQMEAgEFAKCB0TAaBgkqhkiG9w0BCQMxDQYL
# KoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8XDTIzMDQwNzE1Mjk0MlowKwYLKoZI
# hvcNAQkQAgwxHDAaMBgwFgQU84ciTYYzgpI1qZS8vY+W6f4cfHMwLwYJKoZIhvcN
# AQkEMSIEIJFD85kcke8nI+ndjC2Rq/K0umaC9MykTsw1rV74lQDrMDcGCyqGSIb3
# DQEJEAIvMSgwJjAkMCIEIMf04b4yKIkgq+ImOr4axPxP5ngcLWTQTIB1V6Ajtbb6
# MA0GCSqGSIb3DQEBAQUABIICAA02cP984B5H/vEMycLxVb+GU8/HJNOBYsdVNUDw
# 8yTIw0TuFWepgWoV1Q5C8+ocLU/3G72USHCW3yMCgXC+n6s4DiZTT3CP6N56GkXA
# jcSVmTp2LqfEBzc6D582vyQAnxCeYdzXE5m4WW4D/fJ2BRZEHXWq1dhYjAg7uoJI
# 5zSeyHHoN/+cXB4ppugKEk89yN3MSpmKsHHjVjBj/joW3yWJNjwfFK73beBCB5WN
# dCZtOduqFXx0xZzSGkqxKP2XnZz0IYfNXNi9pdz+hy70EL2j3niBMJH00RHDLK7K
# IOWZFewftKLT0S5sfzyBmaI2FOKKkqzSJq+6VneU1Wc3IrtPPpANkNRlv6NN7vjA
# PNTdko2AHcgNVmcDdGwbfYHHxrV+2vOz7yvzBKtojD/cNkBwUkd974h7iKddEdK6
# Fei5EU0piwIoygtLOYlCYPFyqlG3ZU5pRHnGXFbgKRZ0AKmBuF48GXKk/TkCnxZ9
# /1bPT3UvmtbsWeI7KsepoLjX3VBp2kGGdLzcPCWaH7BM0t+EHUMOJWYmwUT2KQt9
# VFqTQji1jhCFy4i+W3kPTKCKOIksIDFFraBzlOgoU1tHRG9KKFkRKG/kffZQ2y2g
# 0DwRbNmtkl+LniItg4Vsnj/6RyGamykhXyVK1+QdF4+m9o6apRxZsFCfhKqIMnfW
# 7LOv
# SIG # End signature block
