#!/bin/bash

if [[ $(id -u) -ne 0 ]]; then
    echo 'Elevation is required to run this script'
    exit 1
fi

OPTIONS=v
LONGOPTS=help,verbose,secrets-path:,username:,password:,client-auth-password:
PARSED=$(getopt --options=$OPTIONS --longoptions=$LONGOPTS --name "$0" -- "$@")

eval set -- "$PARSED"

# Set default parameters
verbose=false

# Relative Paths
orchestratorDllRelative='../Orchestrator.dll'

secretsFileName='orchestratorsecrets.json'

# Display helpful information
display_help() 
{
    echo "[Required] --secrets-path - Absolute path to the orchestratorsecrets configuration file."
    
    echo "Using Web Credentials --"
    echo "[Required] --username - The username that will be used to connect to Keyfactor. (<domain>\\\\<user>)"
    echo "[Required] --password - The password that will be used to connect to Keyfactor."

    echo "Using a Client Authentication Certificate Password --"
    echo "[Required] --client-auth-password - Password used when leveraging certificate authentication to Keyfactor."

    echo "[Optional] --help"
    echo "[Optional] -v, --verbose"

    exit 1 ;
}

# extract options and their arguments into variables.
while true ; do
    case "$1" in
        -v|--verbose)
            verbose=true ; shift ;;
        --help)
            display_help ;;
        --username)
            username="$2" ; shift 2 ;;
        --password)
            password="$2" ; shift 2 ;;
        --client-auth-password)
            clientAuthPassword="$2" ; shift 2 ;;
        --secrets-path)
            secretsPath="$(readlink -m "$2")" ; shift 2 ;;
        --) shift ; break ;;
        *) echo "Unexpected argument $1. Run with --help for assistance." ; exit 1 ;;
    esac
done

if [[ ! $(type -P 'jq') ]]; then
    echo 'jq could not be found on the PATH. Please ensure that the jq utility is installed'
fi

$verbose && echo "Validating input parameters."
if [[ -z "$secretsPath" ]]; then
    echo "Please specify an absolute path to the orchestrator secrets configuration file with --secrets-path."
    exit 1 ;
fi

if [[ "$secretsPath" != /* ]]; then
    # Unix should handle the relative paths based on the cwd, but just in case...
    echo "Invalid path to the orchestrator secrets configuration file. Please specify an absolute path."
    exit 1 ;
fi

if [[ ! -f "$secretsPath" ]]; then
    echo "Specified orchestrator secrets configuration file path '$secretsPath' does not exist."
    exit 1;
fi

if [[ $(basename $secretsPath) != "$secretsFileName" ]]; then
    echo "Specified orchestrator secrets configuration file name is invalid."
    exit 1;
fi

if [[ -z "$username" && -z "$clientAuthPassword" ]]; then
    echo "Please specify either a --username and --password or a --client-auth-password."
    exit 1 ;
fi

if [[ "$clientAuthPassword" && "$username" ]]; then
    echo "Please specify only a --username and --password or a --client-auth-password."
    exit 1 ;
fi

if [[ "$username" && -z "${password+x}" ]]; then
    echo "Please specify a --password."
    exit 1 ;
fi

configurationDirectory=$(dirname $secretsPath)
orchestratorDllPath="$configurationDirectory/$orchestratorDllRelative"

$verbose && echo "Checking for the existence of the Keyfactor Orchestrator at '$orchestratorDllPath'."
if [[ ! -f "$orchestratorDllPath" ]]; then
    echo "The secrets path specified is not contained in an installation of the Keyfactor Orchestrator."
    exit 1;
fi

secretsContent='{}'
if [[ "$username" ]]; then
    # Using web credentials
    $verbose && echo "Using web credentials to authenticate."
    secretsContent="$(echo "$secretsContent" | jq --arg un "$username" '.Secrets.Username = $un')"
    secretsContent="$(echo "$secretsContent" | jq --arg pw "$password" '.Secrets.Password = $pw')"
else
    # Using client certificate auth
    $verbose && echo "Using client certificate authentication."
    secretsContent="$(echo "$secretsContent" | jq --arg cak "$clientAuthPassword" '.Secrets.ClientAuthCertificatePassword = $cak')"
fi

echo "Saving secrets to '$secretsPath'"
echo "$secretsContent" > "$secretsPath"

$verbose && echo "Setting file permissions"
chmod 0600 "$secretsPath"

orchestratorBaseDirectory=$(realpath "$configurationDirectory/../")

# Check for existing services linked to the installation directory and restart them
$verbose && echo "Checking for linked services in the installation directory '$orchestratorBaseDirectory'."
serviceRestarted=false
for f in $(ls -a /etc/systemd/system/keyfactor-orchestrator-* 2> /dev/null); do
    if [ ! -z $(cat $f | grep -E '^WorkingDirectory='"$orchestratorBaseDirectory/?"'$') ]; then
        foundServiceFileName=$(basename $f)
        foundServiceName=${foundServiceFileName%.*}
        $verbose && echo "Linked service '$foundServiceName' discovered."

        echo "Restarting service $foundServiceName"
        systemctl restart $foundServiceFileName
        serviceRestarted=true
    fi
done

$serviceRestarted || echo "An existing orchestrator service could not be found. Restart the orchestrator for these changes to be reflected."