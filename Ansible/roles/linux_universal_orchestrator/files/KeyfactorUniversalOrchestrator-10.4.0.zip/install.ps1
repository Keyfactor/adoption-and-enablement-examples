﻿#Requires -RunAsAdministrator

<#
.SYNOPSIS
Installs and configures Keyfactor Orchestrator

.PARAMETER Source
Directory containing the files to install. Defaults to the directory containing this script.

.PARAMETER Destination
Directory where the orchestrator should be installed.
Must not be specified with -InPlace

.PARAMETER InPlace
If specified, the files will not be copied to another location, and will be configured in their current location.
Must not be specified with -Destination

.PARAMETER ServiceSuffix
Suffix of Windows Service name, after KeyfactorOrchestrator-, primarily for use if installing multiple orchestrators as Windows Services on the same machine.
Must not be specified with -NoService

.PARAMETER ServiceCredential
PSCredential object containing the username/password of the account that the service will run as. If not specified, the service will run as NT AUTHORITY\NETWORK SERVICE
Must not be specified with -NoService

.PARAMETER NoService
If specified, no Windows Service will be created. The configuration will simply be performed so the orchestrator can be manually run later. 
Must not be specified with -ServiceSuffix or -ServiceCredential

.PARAMETER OrchestratorName
Name to report as the orchestrator identifier to the Keyfactor server. If not specified, the value of the COMPUTERNAME environment variable will be used

.PARAMETER URL
URL of the Keyfactor server that this orchestrator should connect to

.PARAMETER NoRevocationCheck
If specified, installation will not check the revocation status of the Keyfactor server certificate, and the 'CheckServerCertificateRevocation' app setting will be set to 'false'.

.PARAMETER WebCredential
PSCredential object containing the username/password that the orchestrator should use to connect to Keyfactor
Must not be specified with -ClientCertificatePemFile, -ClientCertificatePrivateKey, or -ClientCertificateThumbprint

.PARAMETER ClientCertificateThumbprint
The thumbprint that identifies a certificate with a client authentication EKU located in either the machine or service user's certificate store that will be used 
to authenticate to the Keyfactor Command server (if using client authentication). You need only supply a thumbprint or pem file/private key combination. If both 
are supplied, the certificate stores will be searched first. 
Must not be specified with -WebCredential

.PARAMETER ClientCertificate
The path to a pfx file containing the certificate that will be used to authenticate to the Keyfactor Command server (if using client authentication). You need only supply
a thumbprint or pem file/private key combination. If both are supplied, the certificate stores will be searched first. See ClientCertificateThumbprint.
Must be specified with ClientCertificatePassword
Must not be specified with -WebCredential

.PARAMETER ClientCertificatePassword
The password that should be used to access the certificate inside of the pfx provided for ClientCertificate. See ClientCertificate.

.PARAMETER Force
If specified, installation will warn and continue on certain potential conflicts (e.g. overwriting an existing install location or service name).
If this parameter is not specified, such situations will be terminating errors

.PARAMETER Capabilities
If specified, installation will include only the assemblies and manifests in accordance with the user's specification. Valid values are 'all',
'none', and 'ssl'. The default capability suite (not providing this parameter) includes all factory capabilities except for SSL Sync. 

#>

using module ".\Keyfactor.Common.InstallationCommandlets.dll"

[CmdletBinding(PositionalBinding=$false)]
Param(
    [switch]$Force,
    
    [string]$Source,
    
    [string]$Destination,
    
    [switch]$InPlace,
    
    [ValidatePattern('^[A-Za-z0-9]+$')]
    [string]$ServiceSuffix,
    
    [PSCredential]$ServiceCredential,
    
    [switch]$NoService,

    [switch]$NoRevocationCheck,
    
    [ValidatePattern('^[A-Za-z0-9_\.-]+$')]
    [string]$OrchestratorName,
    
    [parameter(Mandatory,HelpMessage='URL of the Keyfactor server that this orchestrator should connect to')]
    [string]$URL,

    [parameter(Mandatory=$false,HelpMessage='PSCredential object containing the username/password that the orchestrator should use to connect to Keyfactor')]
    [PSCredential]$WebCredential,
    
    [parameter(Mandatory=$false,HelpMessage="Thumbprint of the client authentication certificate located in the machine or ServiceCredential user's certificate store")]
    [string]$ClientCertificateThumbprint,
    
    [parameter(Mandatory=$false,HelpMessage='Path to a .pfx file containing your client authentication certificate file')]
    [string]$ClientCertificate,

    [parameter(Mandatory=$false,HelpMessage='The password to the .pfx file containing your client authentication certificate file')]
    [string]$ClientCertificatePassword,

    [parameter(Mandatory=$false,HelpMessage='Specified capability suite to install. Valid values are "all", "none", and "ssl"')]
    [ValidateSet('all', 'none', 'ssl', 'default')]
    [string]$Capabilities
)

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'
$WarningPreference = 'Continue'

#Defaults
$DefaultSource = $PSScriptRoot
$DefaultDestination = 'C:\Program Files\Keyfactor\Keyfactor Orchestrator'
$DefaultServiceUser = 'NT AUTHORITY\NETWORK SERVICE'
$DefaultServiceCredential = New-Object System.Management.Automation.PSCredential ($DefaultServiceUser, (ConvertTo-SecureString 'UnusedPassword' -AsPlainText -Force))
$DefaultServiceSuffix = 'Default'
$DefaultOrchestratorName = $env:COMPUTERNAME
$CapabilityList = [System.Collections.Arraylist]@()
$MINIMUM_SUPPORTED_DOTNET_VERSION = "3.1.0.0";

# Relative paths
$RelativeOrchestratorExePath = '.\Orchestrator.exe'
$RelativeAppSettingsPath = 'configuration\appsettings.json'
$RelativeCredentialsPath = 'configuration\orchestratorsecrets.json'
$RelativeLoggingPath = '.\logs'
$RelativeScriptsPath = '.\Scripts'

$ServicePermissionGranted = $false

function Copy-KeyfactorOrchestratorFiles {
[CmdletBinding()]
Param([string]$Source,[string]$Destination,[System.Collections.ArrayList]$CapabilityList)

    if($Source -eq $Destination) {
        Write-Error "Source and Destination are both set to $Source. If you don't want to copy the files to another location, use the -InPlace flag"
    }

    Write-Verbose "Verifying existence of Keyfactor Orchestrator file in $Source"
    $orchFullPath = Join-Path $Source -ChildPath $RelativeOrchestratorExePath -Resolve

    if(-not (Test-Path $Destination)) {
        Write-Verbose "Destination path $Destination does not exist, and will be created"
        $created = md $Destination
    }

    Write-Verbose "Checking if $Destination is empty"
    $fileCount = (Get-ChildItem $Destination).Length
    if($fileCount -gt 0) {
        if($Force) {
            Write-Warning "Copying into non-empty folder '$Destination'. Files will be overwritten"

            # delete the existing items in the directory
            Get-ChildItem $Destination | Remove-Item -Recurse
            Write-Verbose "$fileCount items removed from '$Destination'"
        }
        else {
            Write-Error "Destination '$Destination' is not empty. Run again with -Force to continue copying to this location"
        }
    }
    
    # exclude the extensions directory
    Get-ChildItem $Source | Where-Object{$_.Name -notin 'extensions'} | Copy-Item -Destination $Destination -Recurse -Force

    # create the extensions directory
    if(!(Test-Path -Path "$Destination/extensions" )) {
        mkdir -p "$Destination/extensions" | Out-Null
    }

    Write-Verbose "Copying extensions to $Destination/extensions"
    foreach ($capability in $CapabilityList)
    {
        switch -Wildcard ($capability)
        {
            'CertStores.IIS*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/IIS")) {
                    Copy-Item -Path "$Source/extensions/IIS" -Destination "$Destination/extensions/IIS" -Recurse -Force
                }
            }

            'CertStores.FTP*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/FTP")) {
                    Copy-Item -Path "$Source/extensions/FTP" -Destination "$Destination/extensions/FTP" -Recurse -Force
                }
            }

            'SSL.*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/SSL")) {
                    Copy-Item -Path "$Source/extensions/SSL" -Destination "$Destination/extensions/SSL" -Recurse -Force
                }
            }

            'Custom.FetchLogs'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/FetchLogs")) {
                    Copy-Item -Path "$Source/extensions/FetchLogs" -Destination "$Destination/extensions/FetchLogs" -Recurse -Force
                }
            }

            'CA.*'
            { 
                if (-not (Test-Path -Path "$Destination/extensions/CertificateAuthority")) {
                    Copy-Item -Path "$Source/extensions/CertificateAuthority" -Destination "$Destination/extensions/CertificateAuthority" -Recurse -Force
                }
            }
        }
    }

    # we should always copy the generic extensions
    if (-not (Test-Path -Path "$Destination/extensions/JobExtensionDrivers")) {
        Copy-Item -Path "$Source/extensions/JobExtensionDrivers" -Destination "$Destination/extensions/JobExtensionDrivers" -Recurse -Force
    }
}

function Join-Url {
Param([Parameter(Mandatory=$true)][string]$BaseUrl,
    [Parameter(Mandatory=$true)][string]$RelativeUrl)

    return "$($BaseUrl.TrimEnd('/'))/$($RelativeUrl.TrimStart('/'))"
}

function Add-KeyfactorConfigurationValue {
[CmdletBinding()]
Param([Parameter(Mandatory, ValueFromPipeline)][Hashtable]$InputObject,
    [Parameter(Mandatory=$true)][string]$Key,
    $Value)

    $keyParts = $Key.Split(':')

    $cursor = $InputObject
    for($i = 0; $i -lt ($keyParts.Count-1); $i++) {
        
        if(-not $cursor[$keyParts[$i]]) {
            $cursor[$keyParts[$i]] = @{}
        }

        $cursor = $cursor[$keyParts[$i]]
    }

    $cursor[$keyParts[-1]] = $Value

    return $InputObject
}

# Since versions before 7 don't have -AsHashTable option on ConvertFrom-Json
# From https://stackoverflow.com/a/34383464/1238851
function Convert-PSObjectToHashtable
{
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process
    {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string])
        {
            $collection = @(
                foreach ($object in $InputObject) { Convert-PSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject])
        {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash[$property.Name] = Convert-PSObjectToHashtable $property.Value
            }

            $hash
        }
        else
        {
            $InputObject
        }
    }
}

function Validate-KeyfactorOrchestratorAuthenticationMethod {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string]$URL,
    
    [Parameter(Mandatory=$false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory=$false)]
    [string]$Thumbprint,

    [Parameter(Mandatory=$false)]
    [string]$Certificate,

    [Parameter(Mandatory=$false)]
    [string]$CertificatePassword
)

    if ($Credential -ne $null)
    {
        Write-Verbose "Validating URL '$URL' and credentials for '$($Credential.UserName)'"
        $statusResp = Keyfactor.Common.InstallationCommandlets\Test-Connection -Uri (Join-Url $URL 'Session/Status') -Credential $Credential -CheckRevocation (-not $NoRevocationCheck)
    }

    if (![string]::IsNullOrEmpty($Thumbprint)) {
        Write-Verbose "Validating URL '$URL' and client auth certificate with thumbprint '$Thumbprint'"
        Write-Verbose "Searching machine store for certificate with thumbprint '$Thumbprint'"
       
        $cert = Get-Item -Path Cert:\LocalMachine\MY\$Thumbprint -ErrorAction SilentlyContinue

        if ($cert -eq $null) {
            Write-Verbose "Certificate with thumbprint '$Thumbprint' was not found in the machine store. Searching the executing user store"          
            $cert = Get-Item -Path Cert:\CurrentUser\MY\$Thumbprint -ErrorAction SilentlyContinue
            if ($cert -ne $null) {
                Write-Warning "The certificate will need to reside in the Personal store of the account that is running the installed service"
            }
        }

        if ($cert -eq $null) {
            Write-Error "Unable to locate a certificate with thumbprint '$Thumbprint' in the personal store of the machine or current user"
        }
        else
        {
            Write-Verbose "Certificate found"
        }

        $statusResp = Keyfactor.Common.InstallationCommandlets\Test-Connection -Uri (Join-Url $URL 'Session/Status') -Certificate $cert -CheckRevocation (-not $NoRevocationCheck)
    }

    if (![string]::IsNullOrEmpty($Certificate) -and ![string]::IsNullOrEmpty($CertificatePassword)) {
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $cert.Import($Certificate, $CertificatePassword, 'EphemeralKeySet')

        $statusResp = Keyfactor.Common.InstallationCommandlets\Test-Connection -Uri (Join-Url $URL 'Session/Status') -Certificate $cert -CheckRevocation (-not $NoRevocationCheck)
    }
}

function Set-KeyfactorOrchestratorConfiguration {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string]$InstallDir,
    
    [Parameter(Mandatory=$false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory=$false)]
    [string]$Thumbprint,

    [Parameter(Mandatory=$false)]
    [string]$Certificate,

    [Parameter(Mandatory=$false)]
    [string]$CertificatePassword,

    [string]$OrchestratorName,
    
	[Parameter(Mandatory=$false)]
    [bool]$NoRevocationCheck
)

    if(-not $OrchestratorName) {
        Write-Verbose "OrchestratorName not expicitly set. Defaulting to $env:COMPUTERNAME"
        $OrchestratorName = $env:COMPUTERNAME
    }

    Write-Verbose 'Computing configuration file paths'
    $credsPath = Join-Path $InstallDir $RelativeCredentialsPath
    $appSettingsPath = Join-Path $InstallDir $RelativeAppSettingsPath

    if ($Credential -ne $null) {
        Write-Verbose "Saving credentials to '$credsPath'"
        $credsFileContent = @{'Secrets' = @{'Username' = $Credential.UserName; 'Password' = $Credential.GetNetworkCredential().Password}}
        ConvertTo-Json $credsFileContent | Set-Content $credsPath
    }

    if (![string]::IsNullOrEmpty($Thumbprint)) {
        # TODO - ConvertTo-Json makes quite ugly JSON, and will trip if someone adds a comment. Consider using Newtonsoft.Json (fairly low risk as it doesn't have dependencies)
        Write-Verbose "Saving client certificate thumbprint to '$appSettingsPath'"
        Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
            Add-KeyfactorConfigurationValue -Key 'AppSettings:AuthCertThumbprint' -Value $Thumbprint |
            ConvertTo-Json | Set-Content $appSettingsPath
    }

    if (![string]::IsNullOrEmpty($Certificate) -and ![string]::IsNullOrEmpty($CertificatePassword)) {
        Write-Verbose "Saving client certificate password to '$credsPath'"
        $credsFileContent = @{'Secrets' = @{'ClientAuthCertificatePassword' = $CertificatePassword; }}
        ConvertTo-Json $credsFileContent | Set-Content $credsPath

        Write-Verbose "Saving client certificate file path to '$appSettingsPath'"
        Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
            Add-KeyfactorConfigurationValue -Key 'AppSettings:CertPath' -Value $Certificate |
            ConvertTo-Json | Set-Content $appSettingsPath
    }

    #because the setting default is true, only need to do this if the flag is true (the flag is backwards to the setting)
    if ($NoRevocationCheck) {
        Write-Verbose "Saving revocation check flag to '$appSettingsPath', turning revocation checking off"
        Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
            Add-KeyfactorConfigurationValue -Key 'AppSettings:CheckServerCertificateRevocation' -Value $false |
            ConvertTo-Json | Set-Content $appSettingsPath
    }

    Write-Verbose "Restricting ACL for $credsPath"
    $credAcl = Get-Acl -Path $credsPath
    $credAcl.SetSecurityDescriptorSddlForm('D:PAI(A;;FA;;;BA)', 'Access') # Restrict to only built-in admins
    Set-Acl -Path $credsPath -AclObject $credAcl

    Write-Verbose "Saving to '$appSettingsPath'"
    Get-Content $appSettingsPath | ConvertFrom-Json | Convert-PSObjectToHashtable |
        Add-KeyfactorConfigurationValue -Key 'AppSettings:AgentsServerUri' -Value $URL |
        Add-KeyfactorConfigurationValue -Key 'AppSettings:OrchestratorName' -Value $OrchestratorName |
        ConvertTo-Json | Set-Content $appSettingsPath
}

function Add-PermissionToFile {
[CmdletBinding()]
Param([string]$Path, [string]$User, [System.Security.AccessControl.FileSystemRights]$Rights)

    $acl = Get-Acl -Path $Path
    Write-Verbose "Granting rights $Rights to $User on $Path"

    if(Test-Path -Path $Path -PathType Container) {
        $acl.AddAccessRule((New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList ($User, $Rights, 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
    }
    else {
        $acl.AddAccessRule((New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList ($User, $Rights, 'Allow')))
    }

    Set-Acl -Path $Path -AclObject $acl
}

function Validate-PermissionOnFile {
[CmdletBinding()]
Param([string]$Path, [string]$User, [System.Security.AccessControl.FileSystemRights]$Rights)
    return (Get-Acl $Path).Access | 
                ?{$_.IdentityReference -eq $User} | 
                ?{($_.FileSystemRights -band $Rights) -eq $Rights}
}

function Grant-LogOnAsAServicePermission {
[CmdletBinding()]
Param([string]$User)
    try 
    {
		Set-LsaPermission -Username $User -Permission "SeServiceLogonRight"
        $ServicePermissionGranted = $true;
    } 
    catch 
    {
       Write-Warning "Failed to grant Log on as a Service permission to user $($User). "
    }
}

# Find linked services by name or path and remove them
function Remove-LinkedKeyfactorOrchestratorServices {
[CmdletBinding()]

	$servicePath = Join-Path $InstallDir -ChildPath $RelativeOrchestratorExePath -Resolve -ErrorAction SilentlyContinue
	$shortName = "KeyfactorOrchestrator-$ServiceSuffix"

	if ($servicePath)
	{
		$cimServicesByPath = Get-KeyfactorOrchestratorServiceByPath $servicePath

		if ($cimServicesByPath) 
		{
			$serviceAlreadyInstalled = "$($cimServicesByPath.Name) is already installed using the executable at $servicePath."
			Uninstall-KeyfactorOrchestratorServices -Services $cimServicesByPath -WarningMessage $serviceAlreadyInstalled
		}
	}

	if (-not $NoService)
	{
		$cimServicesByName = Get-KeyfactorOrchestratorServiceByName $shortName

		if ($cimServicesByName)
		{
			$serviceAlreadyInstalled = "$($cimServicesByName.Name) is already the name of an installed service."
			Uninstall-KeyfactorOrchestratorServices -Services $cimServicesByName -WarningMessage $serviceAlreadyInstalled
		}
	}
}

function Uninstall-KeyfactorOrchestratorServices {
[CmdletBinding()]
Param([object[]]$Services,
    [string]$WarningMessage)

	if($Force)
	{
        ForEach ($service in $Services)
        {
            $serviceName = $service.Name
			Write-Warning "$WarningMessage The existing service will be removed"

			Write-Verbose "Removing existing service $serviceName"
			Stop-Service $serviceName
			Start-Process -FilePath "sc.exe" -ArgumentList "delete $serviceName" -Wait
        }
	}
	else
	{
		Write-Error "$WarningMessage Retry with the -Force flag to overwrite the existing service"
	}
}

function Install-KeyfactorOrchestratorService {
[CmdletBinding()]
Param([string]$ServiceSuffix,
    [PSCredential]$ServiceCredential,
    [string]$InstallDir)

    $shortName = "KeyfactorOrchestrator-$ServiceSuffix"
    $displayName = "Keyfactor Orchestrator Service ($ServiceSuffix)"
    $description = 'Service to perform any remote orchestrator jobs for Keyfactor.'
    $appSettingsPath = Join-Path $InstallDir -ChildPath $RelativeAppSettingsPath -Resolve
    $credentialInUse = $DefaultServiceCredential

    Write-Verbose 'Resolving ServicePath'
    $ServicePath = Join-Path $InstallDir -ChildPath $RelativeOrchestratorExePath -Resolve

    Write-Verbose "Creating new service $shortName"
    $serviceParams = @{
        Name = $shortName;
        BinaryPathName = $ServicePath;
        StartupType = 'Automatic';
        Credential = $ServiceCredential;
        DisplayName = $displayName;
        Description = $description
    }

    
    if($ServiceCredential.UserName.EndsWith('$'))
    {
        $serviceParams['Credential'] = $DefaultServiceCredential
    }

    Write-Verbose "Creating service to run as $($serviceParams['Credential'].UserName)"
    $service = New-Service @serviceParams

    if($ServiceCredential.UserName.EndsWith('$'))
    {
        Write-Verbose "Modifying service to run as $($ServiceCredential.UserName)"
        $serviceObject = Get-CimInstance -ClassName Win32_Service -Filter "name='$shortName'"

        $cimArgs = @{'StartName'= $ServiceCredential.UserName}
        $cimResult = Invoke-CimMethod -InputObject $serviceObject -MethodName Change -Arguments $cimArgs
        
        if($cimResult.ReturnValue -ne 0)
        {
            Write-Warning "Attempt to modify service to run as $($ServiceCredential.UserName) returned $($cimResult.ReturnValue). Change may not have been successful"
        }
    }


    Write-Verbose "Granting necessary file permissions to $($ServiceCredential.UserName)"
    Add-PermissionToFile -Path (Join-Path $InstallDir -ChildPath $RelativeCredentialsPath -Resolve) -User $ServiceCredential.UserName -Rights Modify
    Add-PermissionToFile -Path (Join-Path $InstallDir -ChildPath $RelativeLoggingPath -Resolve) -User $ServiceCredential.UserName -Rights Modify

    if ($ServiceCredential -ne $DefaultServiceCredential) 
    {
        Write-Information "Granting necessary file permissions to $($ServiceCredential.UserName) for configuration file"
        Add-PermissionToFile -Path $appSettingsPath -User $ServiceCredential.UserName -Rights Modify

        Write-Information "Granting Log on as a Service permission to $($ServiceCredential.UserName)"
        Grant-LogOnAsAServicePermission -User $ServiceCredential.UserName 

        $credentialInUse = $ServiceCredential
    }
    else
    {
        Write-Information "Granting necessary file permissions to $($DefaultServiceUser) for configuration file"
        Add-PermissionToFile -Path $appSettingsPath -User $DefaultServiceUser -Rights Modify        
    }

    if (!$(Validate-PermissionOnFile -Path $appSettingsPath -User $credentialInUse.UserName -Rights Modify))
    {
        Write-Error "User $($credentialInUse.UserName) does not have modify permissions on $appSettingsPath"
    }

    Write-Information "Starting service $shortName"
    try
    {
		Start-Service -Name $shortName
    }
    catch
    {
        # Warn the user specifically that the service permission was not granted. Most likely the fix to the thrown exception
        if (!$ServicePermissionGranted)
        {
            Write-Warning "Unable to start the service $shortName. Manually grant the Log on as a Service permission and restart the service."
        }

		Write-Error $error[0]
    }
}

function Get-KeyfactorOrchestratorServiceByName {
[CmdletBinding()]
Param([Parameter(Mandatory=$true)][string]$ServiceName)

    Write-Verbose "Checking for existing services with name '$ServiceName'"
    $cimServices = @(Get-CimInstance Win32_Service -Filter "Name='$ServiceName'")

    Write-Verbose "$($cimServices.Count) services found with name '$ServiceName'"

    return $cimServices
}

function Get-KeyfactorOrchestratorServiceByPath {
[CmdletBinding()]
Param([Parameter(Mandatory=$true)][string]$ServicePath)

    Write-Verbose "Checking for existing services at path '$ServicePath'"  # Easier to cast a wider net and filter in PS than it is to make a precise WQL query
    $cimServices = @(Get-CimInstance Win32_Service -Filter "PathName LIKE '%$(Split-Path -Leaf $ServicePath)%'" | where -FilterScript {$_.PathName.Trim('"') -eq $ServicePath})

    Write-Verbose "$($cimServices.Count) services found at path '$servicePath'"

    return $cimServices
}

function Resolve-Capabilities {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string] $Capabilities,
    [Parameter(Mandatory=$true)][AllowEmptyCollection()][System.Collections.ArrayList]$CapabilityList
)
    $CapabilityList.Add("CertStores.IIS.Inventory") | Out-Null
    $CapabilityList.Add("CertStores.FTP.Inventory") | Out-Null
    $CapabilityList.Add("CertStores.IIS.Reenrollment") | Out-Null
    $CapabilityList.Add("CertStores.F5.Reenrollment") | Out-Null
    $CapabilityList.Add("CertStores.F5.Inventory") | Out-Null
    $CapabilityList.Add("CA.Certificates") | Out-Null
    $CapabilityList.Add("CertStores.F5.Management") | Out-Null
    $CapabilityList.Add("CertStores.IIS.Management") | Out-Null
    $CapabilityList.Add("CA.Templates") | Out-Null
    $CapabilityList.Add("Custom.FetchLogs") | Out-Null
    $CapabilityList.Add("CertStores.FTP.Management") | Out-Null

    if ($Capabilities -eq 'ssl') { 
        $CapabilityList.Clear()
        $CapabilityList.Add("SSL.Discovery") | Out-Null
        $CapabilityList.Add("SSL.Monitoring") | Out-Null
    }

    if ($Capabilities -eq 'all') {
        $CapabilityList.Add("SSL.Discovery") | Out-Null
        $CapabilityList.Add("SSL.Monitoring") | Out-Null
    }

    if ($Capabilities -eq 'none') {
        $CapabilityList.Clear()
    }
}

function Set-EventLogCategories {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string] $Destination
)
    $RegistryPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Application\Keyfactor Orchestrator'
    $MessageFilePath = "$Destination\CSS.CMS.EventLogCategories.dll"
    
    # Now set the value
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'CategoryCount' -Value '27' -Type 'DWORD'
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'TypesSupported' -Value '7' -Type 'DWORD'
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'CategoryMessageFile' -Value $MessageFilePath -Type 'ExpandString'
    Set-RegistryValue -RegistryPath $RegistryPath -Name 'EventMessageFile' -Value "$MessageFilePath;C:\Windows\Microsoft.NET\Framework64\v4.0.30319\EventLogMessages.dll" -Type 'ExpandString'
}

function Set-RegistryValue {
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)][string] $RegistryPath,
    [Parameter(Mandatory=$true)][string] $Name,
    [Parameter(Mandatory=$true)][string] $Value,
    [Parameter(Mandatory=$true)][string] $Type
)
    # Create the key if it does not exist
    If (-NOT (Test-Path $RegistryPath)) {
      New-Item -Path $RegistryPath -Force | Out-Null
    }  

    # Now set the value
    New-ItemProperty -Path $RegistryPath -Name $Name -Value $Value -PropertyType $Type -Force 
}

# MAIN

Write-Verbose 'Checking for .NET Core Runtime 3.1 or greater'
$minimumSupportedVersionFound = $false
if (Get-Command -Name dotnet -ErrorAction SilentlyContinue) {
    $minimumVersion = New-Object -TypeName System.Version -ArgumentList "$MINIMUM_SUPPORTED_DOTNET_VERSION"
    dotnet --list-runtimes | Select-String -Pattern "Microsoft.NETCore.App *" | ForEach-Object {
        $systemVersion = New-Object -TypeName System.Version -ArgumentList "$($_.Line.Split(' ')[1]).0"
        if ($systemVersion -ge $minimumVersion)
        {
            $minimumSupportedVersionFound = $true
            # you can't break inside of this method or PowerShell interprets it as an error
        }
    }
}

if (!$minimumSupportedVersionFound) {
    Write-Error ".NET Core Runtime version $MINIMUM_SUPPORTED_DOTNET_VERSION or later was not found. Please ensure this runtime is installed"
}

Write-Verbose 'Validating parameters'
# if no method of authentication is supplied, we will assume that they want to be prompted for credentials
if ($WebCredential -eq $null -and [string]::IsNullOrEmpty($ClientCertificateThumbprint) -and [string]::IsNullOrEmpty($ClientCertificate)) {
    $WebCredential = Get-Credential   
}

#ensure client auth certificate exists
if ($WebCredential -ne $null -and ![string]::IsNullOrEmpty($ClientCertificateThumbprint) -or $WebCredential -ne $null -and ![string]::IsNullOrEmpty($ClientCertificate)) {
    Write-Error 'Web credentials cannot be specified with a client certificate'
}

if (![string]::IsNullOrEmpty($ClientCertificate) -and [string]::IsNullOrEmpty($ClientCertificatePassword)) {
    Write-Error 'A client certificate pfx was provided without a password.'
}

if($Destination -and $InPlace) {
    Write-Error '-Destination and -InPlace cannot both be specified'
}
if($NoService -and ($ServiceSuffix -or $ServiceCredential)) {
    Write-Error '-NoService cannot be specified with -ServiceSuffix or -ServiceCredential'
}

if($InPlace -and $Capabilities -ne 'all') {
    Write-Error '-InPlace can only be used with capability handling suite "all"'
}

Write-Verbose 'Configuring defaults for unset parameters'
if(-not $Source) {
    Write-Verbose "Source is not explicitly set. Defaulting to $DefaultSource"
    $Source = $DefaultSource
}
if(-not $Destination) {
    Write-Verbose "Destination is not explicitly set. Defaulting to $DefaultDestination"
    $Destination = $DefaultDestination
}
if($InPlace) {
    $InstallDir = $Source
}
else {
    $InstallDir = $Destination
}

if(-not $ServiceCredential) {
    Write-Verbose "Service credential is not explicitly set. Defaulting to $($DefaultServiceCredential.UserName)"
    $ServiceCredential = $DefaultServiceCredential
}
if(-not $ServiceSuffix) {
    Write-Verbose "Service suffix is not explicitly set. Defaulting to $DefaultServiceSuffix"
    $ServiceSuffix = $DefaultServiceSuffix
}
if(-not $OrchestratorName) {
    Write-Verbose "Orchestrator name is not explicitly set. Defaulting to $DefaultOrchestratorName"
    $OrchestratorName = $DefaultOrchestratorName
}

if (-not $Capabilities) {
    Write-Verbose "Capability handling is not explicitly set. Defaulting to 'default'"
    $Capabilities = 'default'
}

# Services that reference the existing files will need to be removed before clearing the directory
Remove-LinkedKeyfactorOrchestratorServices

if(-not $InPlace) {
    Write-Information 'Copying files'
    Resolve-Capabilities $Capabilities $CapabilityList
    Copy-KeyfactorOrchestratorFiles $Source $Destination $CapabilityList
}

# create the logs directory
if(!(Test-Path -Path "$InstallDir/$RelativeLoggingPath" )) {
	Write-Verbose "Creating log directory"
	mkdir -p "$InstallDir/$RelativeLoggingPath" | Out-Null
}

# create the Scripts directory
if(!(Test-Path -Path "$InstallDir/$RelativeScriptsPath" )) {
	Write-Verbose "Creating Scripts directory"
	mkdir -p "$InstallDir/$RelativeScriptsPath" | Out-Null
}

Write-Information 'Setting configuration data'
if ($WebCredential -ne $null){
    Validate-KeyfactorOrchestratorAuthenticationMethod -URL $URL -Credential $WebCredential
    Set-KeyfactorOrchestratorConfiguration -InstallDir $InstallDir -Credential $WebCredential -OrchestratorName $OrchestratorName -NoRevocationCheck $NoRevocationCheck
}

if (![string]::IsNullOrEmpty($ClientCertificateThumbprint))
{
    Validate-KeyfactorOrchestratorAuthenticationMethod -URL $URL -Thumbprint $ClientCertificateThumbprint
    Set-KeyfactorOrchestratorConfiguration -InstallDir $InstallDir -Thumbprint $ClientCertificateThumbprint -OrchestratorName $OrchestratorName -NoRevocationCheck $NoRevocationCheck
}

if (![string]::IsNullOrEmpty($ClientCertificate))
{
    Validate-KeyfactorOrchestratorAuthenticationMethod -URL $URL -Certificate $ClientCertificate -CertificatePassword $ClientCertificatePassword
    Set-KeyfactorOrchestratorConfiguration -InstallDir $InstallDir -Certificate $ClientCertificate -CertificatePassword $ClientCertificatePassword -OrchestratorName $OrchestratorName -NoRevocationCheck $NoRevocationCheck
}

if(-not $NoService) {
    Write-Information 'Installing Windows Service'
    Install-KeyfactorOrchestratorService -InstallDir $InstallDir -ServiceSuffix $ServiceSuffix -ServiceCredential $ServiceCredential
}
else
{
    Write-Warning '-NoService was specified. Your client authentication private key or WebCredential password will not be encrypted until the executable is started.'
}

Write-Verbose 'Updating event log categories in registry'
Set-EventLogCategories -Destination $Destination

# SIG # Begin signature block
# MIIpQAYJKoZIhvcNAQcCoIIpMTCCKS0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBUIvTbwE1FQ0he
# u7PyjXrmxHKlThNcbR/ysDCg/hJP9aCCDi4wggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggd2MIIFXqADAgECAhAPhranjL3m2+B++PUunMN2MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjMwMTMxMDAwMDAwWhcNMjQwMTMw
# MjM1OTU5WjB7MQswCQYDVQQGEwJVUzENMAsGA1UECBMET2hpbzEVMBMGA1UEBxMM
# SW5kZXBlbmRlbmNlMRcwFQYDVQQKEw5LZXlmYWN0b3IsIEluYzEUMBIGA1UECxML
# RW5naW5lZXJpbmcxFzAVBgNVBAMTDktleWZhY3RvciwgSW5jMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEA6eKOGZEUVtAocGpTHAy1/Bgxl1tOWPqdFzFG
# 0w8K+3gGUOB985b+uGJTB6bxYdwtUJcsmZ3cSwSKYbWJBPswivciR9exow7R4asM
# Fz2tSuLkHNEdOg6A5h3Cgl26t3LdEKS/SWNWnhS9GI1r+Cb2B/9/ptJ3fsaR8Z94
# qOz1YfjSK0kxRRABzi6GsP9OXikmFe4ubbnd347B7dTShJFtKhQPhIMOn+ac3YcI
# Jac3+5m7KiLSD6M+hdPS0v1jhBiyn0sS4zrVLrL7IAkNj3mhFCtg2U5Z+Xr4kH+z
# pbfp2v71lyErlVWb5WwdJjGEOo/LSfHZZbwIReZtt2p7R5DCUmFd7ScYimW5+lhK
# 8NGrdvsR4xIWRSBhRBus6t3fnWDhvvDebSKAzC2E39xwqjtiA5hmIF5lrDujOoTK
# dOnnApR55/moQ1GYQX5mAK0rKs90u+PGMEvAG8+E88wm+kXZJswlfJr3Y0nJ7kiA
# t1szJOMU5D8EM1DnSsFqCPWnwgGSgjSOzKebFrYHf7Fs33XmTSwOkusi4iq0bx7G
# WKoKVVZKl1KqN3Wunratgna+GLgdLJA86aBx0HFD8YLM3JlhjnAlxEGtKRiYXpq7
# VyfL7RyR8jcjqnmnynzCEdnNvKZNPQKkc21lQj1okw8ulxMiwceK1I9soK0joWk9
# uvJIVy0CAwEAAaOCAgYwggICMB8GA1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl
# 9E5CMB0GA1UdDgQWBBRFBxQUF8Mbu1SWiMft7H5L5JJc/zAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCBqjBToFGgT4ZNaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25p
# bmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0dHA6Ly9jcmw0LmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNI
# QTM4NDIwMjFDQTEuY3JsMD4GA1UdIAQ3MDUwMwYGZ4EMAQQBMCkwJwYIKwYBBQUH
# AgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzCBlAYIKwYBBQUHAQEEgYcw
# gYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEF
# BQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAU66XgPDhk2SpLMNQtdTMn//V5Xq3Sh7E
# xctsMkQ7BjHBg7ngpmQ8iNSGCfgmQgEp3r4FGKxVegtAwOiOOLzz3VSwCl4mN+Dv
# NauYHHmR2/YGlJKVKnYqVf7WS00dBNOYrh2p5sz+ZjI1vVaBJf8/MHN7r3eKDjyr
# PlH2S3VAivFyUMYbSrCsxJcRBDdCgq2EeKJkYz2mCIV6F0LGqzuse/5CXWCbG4BP
# cMGNX+sd6CZ0SZ7RLfPLSz/d5u6L5G2w4uHPp2gSNXUw90C8q+nxCHDCzJFmXwJu
# DhUchPgcb6Nm5bNawBVrV7VlHP0KoxSTWemB4Xs8axuJ+I1gwrhow1G/EKgD1J0A
# 5+plRlwvVTomIp8empYpNAJfmLKgvEPKHjVaFoeQ0qxlNEixp4YD4wZO0U8cYhH2
# 0wFcEAR+jcxyv5VWWGMj4JMcdC6YorUxG/29U8fG48GldCEz5gkJ4mhbOF11RfR5
# QffkblniZZ7+qZrzQOkMTfGWAI638uDXgCOaejQDoeCKRz6iNbXNpj/fcB7e1Omg
# vmfKK0Ca2kC8PLSiIP5JPmFmplS/5Y136w0JRld18pbgmbTPLzfgSKCGAH5RGa9K
# C5SGS+JUhMJ6MxTKc97dXfhZaE4KUjiKQj2iLPnXm1AZDkt4C9coxnKbwbFic0Bw
# uSelnVg6avcxghpoMIIaZAIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5E
# aWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2Rl
# IFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTECEA+GtqeMvebb4H749S6c
# w3YwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3AgEMMQIwADAZBgkqhkiG9w0B
# CQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAv
# BgkqhkiG9w0BCQQxIgQgQJL8EfJP+UeCDBJzQFw5EWHRvl4xebqGYFAZuistA5Uw
# DQYJKoZIhvcNAQEBBQAEggIAIVv3lysqsCnOfLPKliIn3Y44luj0YyrAKFoAJ2nF
# j/jNYWKpYq1usLGVu8H2w4U8y5VpnywVqqSdw3QPttoG+6SS98X+n1f6QBwCVLPE
# 5+Jz3ha9OsEoeYBrFqOm8LZXDS0fRCBxnHLGlZ9qsrKOXVyt2C3IHg7GGeai7tP2
# ZOqP99jzUR9u0XBEXXI44jIOGxmSsWZq43XUObjimLxpg2YWc+el4h2TNDmYyrAa
# gPptY9ltFdV40WI4n73rVeeR12wllY+ix50rGZIWDCTfIrCOKgm/gxDFbfp6YwlD
# Jmo8ujuGEH7oLRw9cm2sRev/UDgB5FRSAS26eBLEgiLc9sgc8+zjVJhSri36bxa9
# MCj1ZzaB/ISzVfsHozWGj/pO80pNUCSQKuPodQkgoKi9PRBp36G6lHI4/jcd//8o
# IM49Y5pY+3JPYcD9f/vNEYK9/fLq5o001SQeL4XaC8vyS46wP52tdhFr83TUAMPI
# tTeE/uUj/F6YuugApUlY9kLLNz/ybRIbEPSLtmzvMdqWlNREJZWOonCNkUg49/y1
# wN0JaxOGRkq2Qb6Tqy/cDkrQ0YK9uVmpm3x4K9HuzF+9iYZP+30i7Qm0ipIbtROH
# 5KuDcxBAKdcDphpdM8OFlp1az+HdIDk+PSPrW9AePWQJynP1XFbF3nf1rSTxRC1S
# 4+6hghc+MIIXOgYKKwYBBAGCNwMDATGCFyowghcmBgkqhkiG9w0BBwKgghcXMIIX
# EwIBAzEPMA0GCWCGSAFlAwQCAQUAMHgGCyqGSIb3DQEJEAEEoGkEZzBlAgEBBglg
# hkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgthOrqcwB7v4n9aNoNeyafncmZ+4a
# sMS8+OoOA1QQLlMCEQDXixY3AhcQFNt2OYHpndytGA8yMDIzMDUyNjIyNDExNlqg
# ghMHMIIGwDCCBKigAwIBAgIQDE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsF
# ADBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNV
# BAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1w
# aW5nIENBMB4XDTIyMDkyMTAwMDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UE
# BhMCVVMxETAPBgNVBAoTCERpZ2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1l
# c3RhbXAgMjAyMiAtIDIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP
# 7KUmOsap8mu7jcENmtuh6BSFdDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9
# BoMW15GSOBwxApb7crGXOlWvM+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW
# 4VbGwLpkU7sqFudQSLuIaQyIxvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJh
# vKo6B332q27lZt3iXPUv7Y3UTZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4
# DeWMlF0ZWr/1e0BubxaompyVR4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AG
# N7oI2TWmtR7aeFgdOej4TJEQln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMR
# oku7mL/6T+R7Nu8GRORV/zbq5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5Af
# J7fSqxTlOGaHUQhr+1NDOdBk+lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU
# 4b3ZXUtuMZQpi+ZBpGWUwFjl5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5q
# BzliGcnWhX8T2Y15z2LF7OF7ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstk
# ifGxxLjnU15fVdJ9GSlZA076XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqU
# FN9SnDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl
# 5vdyipjDd9Rk/BX7NsJJUSx4iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18
# hc1Tna9i4mFmoxQqRYdKmEIrUPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ
# 6KO4ndetHxy47JhB8PYOgPvk/9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/
# fl4JrXZUinRtytIFZyt26/+YsiaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIM
# kU88ZpSvXQJT657inuTTH4YBZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMM
# xkZAO85dNdRZPkOaGK7DycvD+5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7
# /lxClIGUgp2sCovGSxVK05iQRWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0
# Ti7aHh2MWsgemtXC8MYiqE+bvdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpL
# EQLIgpzJGgV8unG1TnqZbPTontRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+
# 8JeEeOMIA11HLGOoJTiXAdI/Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYks
# Jxlh9ncBjDCCBq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYqXlswDQYJKoZIhvcN
# AQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3Rl
# ZCBSb290IEc0MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIzNTk1OVowYzELMAkG
# A1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdp
# Q2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJs8E9cklRVcclA8Ty
# kTepl1Gh1tKD0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJC3+dH54PMx9QEwsm
# c5Zt+FeoAn39Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+QtxnjupRPfDWVtTn
# KC3r07G1decfBmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3eZ9drMvohGS0UvJ2
# R/dhgxndX7RUCyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbFHc02DVzV5huowWR0
# QKfAcsW6Th+xtVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71h6aPTnYVVSZwmCZ/
# oBpHIEPjQ2OAe3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseSv6De4z6ic/rnH1ps
# lPJSlRErWHRAKKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj1QPgv/CiPMpC3BhI
# fxQ0z9JMq++bPf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2LINIsVzV5K6jzRWC8
# I41Y99xh3pP+OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJjAw7W4oiqMEmCPkU
# EBIDfV8ju2TjY+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAOhFTuzuldyF4wEr1G
# nrXTdrnSDmuZDNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEA
# MB0GA1UdDgQWBBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNVHSMEGDAWgBTs1+OC
# 0nFdZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwdwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5k
# aWdpY2VydC5jb20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSG
# Mmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQu
# Y3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0B
# AQsFAAOCAgEAfVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88wU86/GPvHUF3iSyn7
# cIoNqilp/GnBzx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZvxFBMYh0MCIKoFr2p
# Vs8Vc40BIiXOlWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+RZp4snuCKrOX9jLxk
# Jodskr2dfNBwCnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM8HKjI/rAJ4JErpkn
# G6skHibBt94q6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/Ex8HBanHZxhOACcS2
# n82HhyS7T6NJuXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd/yVjmScsPT9rp/Fm
# w0HNT7ZAmyEhQNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFPvT87eK1MrfvElXvt
# Cl8zOYdBeHo46Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHicsJttvFXseGYs2uJPU
# 5vIXmVnKcPA3v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2VQbc61RWYMbRiCQ8K
# vYHZE/6/pNHzV9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ8GV2QqYphwlHK+Z/
# GqSFD/yYlvZVVCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr9u3WfPwwggWNMIIE
# daADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNV
# BAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdp
# Y2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAe
# Fw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUw
# EwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20x
# ITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcN
# AQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC
# 4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWl
# fr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1j
# KS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dP
# pzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3
# pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJ
# pMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aa
# dMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXD
# j/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB
# 4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ
# 33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amy
# HeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC
# 0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823I
# DzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYD
# VR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcN
# AQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxpp
# VCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6
# mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPH
# h6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCN
# NWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg6
# 2fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQxggN2MIIDcgIBATB3MGMxCzAJBgNV
# BAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNl
# cnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAxN
# aXJLlPo8Kko9KQeAPVowDQYJYIZIAWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0G
# CyqGSIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yMzA1MjYyMjQxMTZaMCsGCyqG
# SIb3DQEJEAIMMRwwGjAYMBYEFPOHIk2GM4KSNamUvL2Plun+HHxzMC8GCSqGSIb3
# DQEJBDEiBCAuO1SWLp1uDxSshxi7Dsr1a3QuQpE3+ECTkgIAx8eV/DA3BgsqhkiG
# 9w0BCRACLzEoMCYwJDAiBCDH9OG+MiiJIKviJjq+GsT8T+Z4HC1k0EyAdVegI7W2
# +jANBgkqhkiG9w0BAQEFAASCAgBl7jsB3SEmbQfHXPf804aM0pIjf/wuh/6kcsfd
# 0uvFyDLmxwlHmh9eD/Rw5OkyC6AksesVDlkw5fc3ddLIn0qmBjp/dvBdBAJW5tsv
# z85cztACmQffKe14K04YRyLwaHhDnBnKIG/t2j95wAmGklTkzPElJtcqbJJdNh5N
# Q8Wa4yGDBWwp/3O5ZFzjgroR+7CiNVAMV0N+oDNz/eS6vuq/PWqqtr/I1wMou9nT
# CuT7BZTjYEeiSK+Jbo1JqrEIEIABPmY0/6NOpTkX9QZXMqSNyQR6h94KzNF33Hyz
# 17Erjfxm8Xf6Lfgg5v01+n9S6jw2u+BliNTtlgnG7ickqdw23nD9j1b/rF2Dpc4E
# rr0erXIe5wtjLgRWwqxK1UC+nTW9URu9rTxwf88izltONB2xiuxr2CCiCdV5J1Ve
# 7z25E0nei1NGRDpLpIxl9RygjB4RHtnuO4qBauKh2jNfRDsN4Pr/OSNVTOv89p73
# wVfHVbI5I0VJITZQr3PP0CABOi3oOc9zcj09mW7V5GfiJZO094dugY5uFSO5Smr5
# HwX45KDy4tmlpyBBAORvxNov/Emioyr/C58VFqwwextmk3JFII3Hfa7ftOqvREo7
# Bml1q/26Y3yIw4pUGtNRvgT+21hhZ/KGwEEtScW8XXJ4WRpxKtH350EYW47z7zW7
# GOtZBg==
# SIG # End signature block
